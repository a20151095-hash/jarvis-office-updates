#!/usr/bin/env python3
"""자비스 사무실: 로컬 세션 기록을 읽기 전용으로 관찰하는 서버.

Python 3.10+ 표준 라이브러리만 사용합니다. AI를 실행하거나 설정을 바꾸지
않으며, 외부 네트워크에 요청하지 않습니다. 세션 원문은 HTTP로 보내지 않습니다.
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import heapq
import importlib
import json
import ntpath
import os
from pathlib import Path
import re
import stat
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit
import webbrowser

VERSION = "0.3.0"
ROOT = Path(__file__).absolute().parent
MAX_FILES = 96
MAX_INITIAL_BYTES = 256 * 1024
MAX_LINE_BYTES = 1024 * 1024
MAX_TICK_BYTES = 1024 * 1024
MAX_FILE_CHUNK = 64 * 1024
MAX_SCAN_ENTRIES = 20000
MAX_SCAN_DIRS = 4096
MAX_AGENTS = 256
MAX_PROJECTS = 96
MAX_EVENTS = 100
KINDS = {
    "read": "파일 읽기", "write": "파일 수정", "execute": "명령 실행",
    "search": "정보 검색", "plan": "계획 정리", "ask": "사용자 입력 대기",
    "delegate": "동료에게 작업 전달", "start": "작업 시작 기록",
    "complete": "작업 완료 기록", "error": "오류 기록 확인",
    "idle": "도구 작업 종료",
}
PROVIDER_NAMES = {"claude": "Claude", "codex": "Codex"}
# Preserve only labels that the adapters themselves define. A generic kind
# cannot distinguish writing an answer from changing a file, or interruption
# from a successful tool return. Never accept a label copied from a transcript.
ADAPTER_LABELS = {
    "claude": {
        "read": {"파일 읽기", "파일 찾기", "내용 검색", "작업 결과 확인", "작업 지침 읽기"},
        "write": {"파일 작성", "코드 수정", "노트북 수정"},
        "execute": {"명령 실행", "작업 중지 요청"},
        "search": {"웹 검색", "웹페이지 읽기", "연결 도구 찾기", "연결 도구 호출"},
        "plan": {"계획 모드 진입", "작업 계획 갱신", "작업 계획 추가", "작업 계획 확인"},
        "ask": {"계획 확인 요청", "사용자 확인 요청"},
        "delegate": {"작업 위임"},
        "start": {"요청 기록 관찰"},
        "idle": {"도구 작업 종료"},
        "error": {"도구 오류"},
    },
    "codex": {
        "read": {"자료 읽기"}, "write": {"파일 수정", "답변 작성"},
        "execute": {"명령 실행"}, "search": {"정보 검색"},
        "plan": {"작업 계획", "작업 검토"}, "ask": {"사용자 확인 대기"},
        "delegate": {"협업 작업 요청"},
        "start": {"작업 시작", "협업 에이전트 합류"},
        "complete": {"작업 완료", "협업 작업 완료"},
        "error": {"작업 오류", "도구 작업 오류", "협업 요청 오류"},
        "idle": {"다음 작업 대기", "도구 응답 수신", "도구 작업 종료", "협업 작업 중단", "작업 중단"},
    },
}


def iso_time(value=None):
    """Normalize a timestamp, retaining UTC and never inventing an event time."""
    if value is None:
        return None
    try:
        if isinstance(value, (float, int)) and not isinstance(value, bool):
            moment = datetime.fromtimestamp(value, timezone.utc)
        elif isinstance(value, str):
            moment = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if moment.tzinfo is None:
                # Log formats sometimes omit a timezone; do not assume a zone.
                return None
            moment = moment.astimezone(timezone.utc)
        else:
            return None
        return moment.isoformat(timespec="milliseconds").replace("+00:00", "Z")
    except (ValueError, OverflowError, OSError):
        return None


def opaque(namespace, value):
    return namespace + ":" + hashlib.sha256(str(value).encode("utf-8", "replace")).hexdigest()[:20]


def display_basename(value):
    if not isinstance(value, str) or not value:
        return None
    value = ntpath.basename(value.rstrip("/\\"))
    value = "".join(ch for ch in value if ch.isprintable())[:60].strip()
    return value if value not in ("", ".", "..") else None


def safe_tool(value):
    if not isinstance(value, str):
        return ""
    return value if re.fullmatch(r"[A-Za-z][A-Za-z0-9_:.\-/]{0,119}", value) else ""


def safe_label(provider, kind, value):
    allowed = ADAPTER_LABELS.get(provider, {}).get(kind, set())
    return value if isinstance(value, str) and value in allowed else KINDS[kind]


def within_root(path, root):
    """Reject symlinks in the observed root and every relative component."""
    try:
        parts = path.relative_to(root).parts
        if root.is_symlink():
            return False
        current = root
        for component in parts:
            current = current / component
            if current.is_symlink():
                return False
        return path.resolve().is_relative_to(root.resolve())
    except AttributeError:  # Python 3.9 compatibility for alternate runtimes.
        try:
            path.resolve().relative_to(root.resolve())
            return True
        except (ValueError, OSError, RuntimeError):
            return False
    except (ValueError, OSError, RuntimeError):
        return False


class FileCursor:
    def __init__(self, path, root, provider):
        self.path = path
        self.root = root
        self.provider = provider
        self.file_id = opaque("file", str(path))
        self.offset = 0
        self.buffer = b""
        self.buffer_start = 0
        self.discard_line = False
        self.identity = None
        self.last_mtime_ns = None
        self.tail_probe = b""
        self.initialized = False
        self.context = self.new_context()

    def new_context(self):
        relative = self.path.relative_to(self.root)
        is_subagent = "subagents" in relative.parts or self.path.name.startswith("agent-")
        parent = None
        agent_id = None
        if self.provider == "claude" and "subagents" in relative.parts:
            index = relative.parts.index("subagents")
            if index > 0:
                parent = relative.parts[index - 1]
        if is_subagent and self.path.name.startswith("agent-"):
            agent_id = self.path.stem.removeprefix("agent-")
        project_seed = relative.parts[0] if self.provider == "claude" and len(relative.parts) > 1 else "unknown"
        return {
            "file_id": self.file_id,
            "project_id": opaque("project", self.provider + ":" + project_seed),
            "session_id": self.path.stem if self.provider == "claude" and not is_subagent else self.file_id,
            "is_subagent": is_subagent,
            "parent_session_id": parent,
            **({"agent_id": agent_id} if agent_id else {}),
        }

    def reset(self):
        self.offset = 0
        self.buffer = b""
        self.buffer_start = 0
        self.discard_line = False
        self.initialized = False
        self.last_mtime_ns = None
        self.tail_probe = b""
        self.context = self.new_context()


class Monitor:
    """Incremental, bounded reader. Tests can inject parsers and temporary roots."""
    def __init__(self, claude_dir, codex_dir, parsers=None):
        self.roots = {
            "claude": Path(claude_dir).expanduser().absolute(),
            "codex": Path(codex_dir).expanduser().absolute(),
        }
        self.parsers = parsers if parsers is not None else {
            provider: getattr(importlib.import_module(provider + "_adapter"), "parse_" + provider)
            for provider in self.roots
        }
        self.cursors = {}
        self.projects = collections.OrderedDict()
        self.agents = collections.OrderedDict()
        self.events = collections.deque(maxlen=MAX_EVENTS)
        self.seen = collections.OrderedDict()
        self.diagnostics = {"malformedLines": 0, "readErrors": 0}
        self.available = {provider: False for provider in self.roots}
        self.source_errors = {provider: False for provider in self.roots}
        self.last_scan_at = None
        self.last_scan = -float("inf")
        self.last_event_at = None
        self.round_robin = 0
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.thread = None

    def _discover(self, provider, root):
        found = []
        self.source_errors[provider] = False
        try:
            available = root.is_dir() and not root.is_symlink()
        except OSError:
            available = False
        self.available[provider] = available
        if not available:
            return found
        queue = collections.deque([root])
        scanned_dirs = scanned_entries = 0
        while queue and scanned_dirs < MAX_SCAN_DIRS and scanned_entries < MAX_SCAN_ENTRIES:
            directory = queue.popleft()
            scanned_dirs += 1
            try:
                if not within_root(directory, root):
                    continue
                with os.scandir(directory) as entries:
                    for entry in entries:
                        scanned_entries += 1
                        if scanned_entries > MAX_SCAN_ENTRIES:
                            break
                        if entry.is_symlink():
                            continue
                        if entry.is_dir(follow_symlinks=False):
                            queue.append(Path(entry.path))
                        elif entry.name.endswith(".jsonl") and entry.is_file(follow_symlinks=False):
                            info = entry.stat(follow_symlinks=False)
                            found.append((info.st_mtime, provider, Path(entry.path)))
            except OSError:
                self.diagnostics["readErrors"] += 1
                self.source_errors[provider] = True
        return found

    def scan(self):
        with self.lock:
            candidates = []
            for provider, root in self.roots.items():
                candidates.extend(self._discover(provider, root))
            selected = sorted(heapq.nlargest(MAX_FILES, candidates), key=lambda item: item[0])
            retained = {}
            for _, provider, path in selected:
                key = (provider, str(path))
                retained[key] = self.cursors.get(key) or FileCursor(path, self.roots[provider], provider)
            self.cursors = retained
            self.last_scan = time.monotonic()
            self.last_scan_at = iso_time(time.time())

    def _metadata(self, record, cursor):
        provider = cursor.provider
        context = cursor.context
        metadata = record.get("payload") if provider == "codex" and record.get("type") == "session_meta" else record
        if not isinstance(metadata, dict):
            return
        cwd = metadata.get("cwd")
        name = display_basename(cwd)
        if name:
            context["project_id"] = opaque("project", provider + ":" + cwd.replace("\\", "/").rstrip("/"))
            context["project_name"] = name
        if provider == "codex" and record.get("type") == "session_meta":
            if isinstance(metadata.get("id"), str):
                context["session_id"] = metadata["id"]
            source = metadata.get("source")
            if isinstance(source, dict):
                subagent = source.get("subagent")
                spawn = subagent.get("spawn") if isinstance(subagent, dict) else None
                parent = spawn.get("parent_thread_id") if isinstance(spawn, dict) else None
                if isinstance(parent, str):
                    context["is_subagent"] = True
                    context["parent_session_id"] = parent
        elif provider == "claude":
            session = metadata.get("sessionId") or metadata.get("session_id")
            if isinstance(session, str) and session and not context.get("is_subagent"):
                context["session_id"] = session
        project_id = context["project_id"]
        self.projects[project_id] = {
            "id": project_id,
            "name": context.get("project_name") or (PROVIDER_NAMES[provider] + " 프로젝트"),
            "provider": provider,
        }
        self.projects.move_to_end(project_id)
        while len(self.projects) > MAX_PROJECTS:
            self.projects.popitem(last=False)

    def _record(self, raw_line, cursor, position, file_mtime, metadata_only=False):
        try:
            record = json.loads(raw_line.decode("utf-8-sig"))
            if not isinstance(record, dict):
                raise ValueError("record is not an object")
        except (UnicodeDecodeError, ValueError, RecursionError):
            self.diagnostics["malformedLines"] += 1
            return
        self._metadata(record, cursor)
        if metadata_only:
            # Let metadata-aware adapters establish IDs, without replaying history.
            if record.get("type") == "session_meta":
                try:
                    self.parsers[cursor.provider](record, cursor.context)
                except (Exception,):
                    self.diagnostics["readErrors"] += 1
            return
        try:
            observed = self.parsers[cursor.provider](record, cursor.context)
        except Exception:
            # A future log schema must never kill monitoring or expose raw data.
            self.diagnostics["readErrors"] += 1
            return
        if not isinstance(observed, list):
            return
        for index, event in enumerate(observed[:32]):
            if not isinstance(event, dict) or event.get("kind") not in KINDS:
                continue
            provider = cursor.provider
            raw_session = event.get("session_id") or cursor.context["session_id"]
            raw_agent = event.get("agent_id") or raw_session
            raw_parent = event.get("parent_id")
            identity_input = "|".join((provider, str(raw_session), str(raw_agent), str(position), str(index), hashlib.sha256(raw_line).hexdigest()))
            event_id = opaque("event", identity_input)
            if event_id in self.seen:
                continue
            self.seen[event_id] = True
            while len(self.seen) > 4096:
                self.seen.popitem(last=False)
            session_id = opaque(provider + ":session", raw_session)
            agent_id = opaque(provider + ":agent", raw_agent)
            parent_id = opaque(provider + ":agent", raw_parent) if raw_parent else None
            project_id = cursor.context["project_id"]
            # A copied/touched file may have a recent mtime and very old records.
            # Unknown event times must stay unknown instead of looking live.
            timestamp = iso_time(event.get("timestamp")) or iso_time(record.get("timestamp"))
            kind = event["kind"]
            tool = safe_tool(event.get("tool", ""))
            label = safe_label(provider, kind, event.get("label"))
            normalized = {
                "id": event_id, "projectId": project_id, "sessionId": session_id,
                "agentId": agent_id, "provider": provider, "kind": kind,
                "label": label, "tool": tool, "time": timestamp,
            }
            self.events.append(normalized)
            if timestamp and (not self.last_event_at or timestamp > self.last_event_at):
                self.last_event_at = timestamp
            previous = self.agents.get(agent_id)
            if previous and previous.get("updatedAt") and timestamp and timestamp < previous["updatedAt"]:
                continue
            is_subagent = bool(parent_id or (cursor.context.get("is_subagent") and str(raw_agent) == str(cursor.context.get("agent_id", cursor.context.get("session_id")))))
            if is_subagent:
                name = previous["name"] if previous else "동료 " + str(1 + sum(bool(agent["parentId"]) for agent in self.agents.values()))
            else:
                name = "자비스 (" + PROVIDER_NAMES[provider] + ")"
            self.agents[agent_id] = {
                "id": agent_id, "projectId": project_id, "sessionId": session_id,
                "parentId": parent_id, "provider": provider, "name": name,
                "kind": kind, "label": label, "tool": tool,
                "updatedAt": timestamp,
            }
            self.agents.move_to_end(agent_id)
            while len(self.agents) > MAX_AGENTS:
                self.agents.popitem(last=False)

    def _read_cursor(self, cursor, budget):
        if not within_root(cursor.path, cursor.root):
            return 0
        descriptor = None
        try:
            flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
            descriptor = os.open(cursor.path, flags)
            info = os.fstat(descriptor)
            if not stat.S_ISREG(info.st_mode):
                return 0
            if not within_root(cursor.path, cursor.root):
                return 0
            identity = (info.st_dev, info.st_ino)
            if cursor.identity is not None and (cursor.identity != identity or info.st_size < cursor.offset):
                cursor.reset()
            elif cursor.initialized and cursor.last_mtime_ns != info.st_mtime_ns:
                # Detect a truncate/rewrite that happened entirely between polls.
                changed_prefix = False
                if cursor.tail_probe and info.st_size >= cursor.offset:
                    os.lseek(descriptor, cursor.offset - len(cursor.tail_probe), os.SEEK_SET)
                    changed_prefix = os.read(descriptor, len(cursor.tail_probe)) != cursor.tail_probe
                if changed_prefix or info.st_size <= cursor.offset:
                    cursor.reset()
            cursor.identity = identity
            cursor.last_mtime_ns = info.st_mtime_ns
            if not cursor.initialized:
                cursor.initialized = True
                if info.st_size > MAX_INITIAL_BYTES:
                    # Recover the usual first-line metadata without reading a huge log.
                    # A rewrite probe may have left the descriptor near its tail.
                    os.lseek(descriptor, 0, os.SEEK_SET)
                    head = os.read(descriptor, min(MAX_FILE_CHUNK, info.st_size))
                    first, separator, _ = head.partition(b"\n")
                    if separator:
                        self._record(first, cursor, 0, info.st_mtime, metadata_only=True)
                    cursor.offset = max(0, info.st_size - MAX_INITIAL_BYTES)
                    cursor.buffer_start = cursor.offset
                    cursor.discard_line = cursor.offset > 0
            if info.st_size <= cursor.offset:
                return 0
            os.lseek(descriptor, cursor.offset, os.SEEK_SET)
            data = os.read(descriptor, min(budget, MAX_FILE_CHUNK))
            if not data:
                return 0
            if not cursor.buffer:
                cursor.buffer_start = cursor.offset
            cursor.offset += len(data)
            cursor.tail_probe = (cursor.tail_probe + data)[-128:]
            cursor.buffer += data
            while b"\n" in cursor.buffer:
                line, _, remainder = cursor.buffer.partition(b"\n")
                line_position = cursor.buffer_start
                cursor.buffer_start += len(line) + 1
                cursor.buffer = remainder
                if cursor.discard_line:
                    cursor.discard_line = False
                    continue
                if len(line) > MAX_LINE_BYTES:
                    self.diagnostics["malformedLines"] += 1
                    continue
                if line.strip():
                    self._record(line.rstrip(b"\r"), cursor, line_position, info.st_mtime)
            if len(cursor.buffer) > MAX_LINE_BYTES:
                cursor.buffer_start += len(cursor.buffer)
                cursor.buffer = b""
                if not cursor.discard_line:
                    self.diagnostics["malformedLines"] += 1
                cursor.discard_line = True
            return len(data)
        except (OSError, RuntimeError):
            self.diagnostics["readErrors"] += 1
            self.source_errors[cursor.provider] = True
            return 0
        finally:
            if descriptor is not None:
                os.close(descriptor)

    def tick(self, force_scan=False):
        with self.lock:
            if force_scan or time.monotonic() - self.last_scan >= 3.0:
                self.scan()
            cursors = list(self.cursors.values())
            if not cursors:
                return
            begin = self.round_robin % len(cursors)
            cursors = cursors[begin:] + cursors[:begin]
            self.round_robin += 1
            budget = MAX_TICK_BYTES
            for cursor in cursors:
                if budget <= 0:
                    break
                budget -= self._read_cursor(cursor, budget)

    def snapshot(self):
        with self.lock:
            referenced = {agent["projectId"] for agent in self.agents.values()} | {event["projectId"] for event in self.events}
            return {
                "schema": 1, "mode": "live", "serverTime": iso_time(time.time()),
                "lastEventAt": self.last_event_at,
                "sources": [{"provider": provider, "available": self.available[provider],
                             "lastCheckedAt": self.last_scan_at, "readError": self.source_errors[provider],
                             "files": sum(cursor.provider == provider for cursor in self.cursors.values())}
                            for provider in self.roots],
                "projects": [dict(project) for project in self.projects.values() if project["id"] in referenced],
                "agents": [dict(agent) for agent in self.agents.values()],
                "events": sorted((dict(event) for event in reversed(self.events)), key=lambda event: event["time"] or "", reverse=True),
                "diagnostics": dict(self.diagnostics),
            }

    def start(self):
        self.tick(force_scan=True)
        def loop():
            while not self.stop_event.wait(0.5):
                self.tick()
        self.thread = threading.Thread(target=loop, name="office-log-observer", daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=2)


class OfficeHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 16

    def __init__(self, monitor, port=8765, index_file=None):
        self.monitor = monitor
        self.index_file = Path(index_file) if index_file else ROOT / "index.html"
        super().__init__(("127.0.0.1", port), OfficeHandler)


class OfficeHandler(BaseHTTPRequestHandler):
    server_version = "JarvisOffice/" + VERSION
    sys_version = ""

    def setup(self):
        super().setup()
        self.connection.settimeout(5)

    def log_message(self, _format, *args):
        # URLs and request data need not be retained or printed.
        pass

    def _reply(self, code, body, content_type="application/json; charset=utf-8"):
        if not isinstance(body, bytes):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "default-src 'none'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'")
        self.send_header("Connection", "close")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _allowed(self):
        port = self.server.server_port
        hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
        if self.headers.get("Host", "").lower() not in hosts:
            self._reply(403, {"error": "허용되지 않은 호스트입니다."})
            return False
        origin = self.headers.get("Origin")
        if origin is not None and origin.lower() not in {"http://" + host for host in hosts}:
            self._reply(403, {"error": "다른 웹사이트에서 접근할 수 없습니다."})
            return False
        if self.headers.get("Sec-Fetch-Site", "").lower() == "cross-site":
            self._reply(403, {"error": "다른 웹사이트에서 접근할 수 없습니다."})
            return False
        return True

    def do_GET(self):
        if not self._allowed():
            return
        path = urlsplit(self.path).path
        if path in ("/", "/index.html"):
            try:
                body = self.server.index_file.read_bytes()
            except OSError:
                self._reply(503, {"error": "index.html 파일이 필요합니다. 압축을 모두 풀어 주세요."})
                return
            self._reply(200, body, "text/html; charset=utf-8")
        elif path in {"/assets/chiikawa.svg", "/assets/hachiware.svg", "/assets/usagi.svg"}:
            try:
                self._reply(200, (self.server.index_file.parent / path.lstrip("/")).read_bytes(), "image/svg+xml")
            except OSError:
                self._reply(404, {"error": "캐릭터 에셋 없음"})
        elif path == "/api/state":
            self._reply(200, self.server.monitor.snapshot())
        elif path == "/api/health":
            self._reply(200, {"ok": True, "version": VERSION, "readOnly": True, "boundTo": "127.0.0.1"})
        else:
            self._reply(404, {"error": "없는 경로입니다."})

    def do_POST(self):
        self._reply(405, {"error": "읽기 전용 서버입니다."})

    do_PUT = do_POST
    do_DELETE = do_POST
    do_PATCH = do_POST
    do_OPTIONS = do_POST
    do_HEAD = do_POST


def main(argv=None):
    parser = argparse.ArgumentParser(description="자비스 사무실 — 로컬 AI 세션 기록 읽기 전용 관찰")
    parser.add_argument("--port", type=int, default=8765, help="로컬 포트 (기본 8765)")
    parser.add_argument("--no-browser", action="store_true", help="브라우저를 자동으로 열지 않음")
    parser.add_argument("--claude-dir", default=str(Path.home() / ".claude" / "projects"), help="Claude Code 세션 폴더")
    parser.add_argument("--codex-dir", default=str(Path(os.environ.get("CODEX_HOME", str(Path.home() / ".codex"))) / "sessions"), help="Codex 세션 폴더")
    args = parser.parse_args(argv)
    if not 1 <= args.port <= 65535:
        parser.error("포트는 1~65535 범위여야 합니다.")
    try:
        monitor = Monitor(args.claude_dir, args.codex_dir)
        server = OfficeHTTPServer(monitor, port=args.port)
    except ImportError:
        print("오류: 어댑터 파일이 없습니다. ZIP 파일의 내용을 모두 같은 폴더에 풀어 주세요.")
        return 1
    except OSError:
        print("오류: 로컬 포트를 열 수 없습니다. 이미 실행 중이라면 기존 창을 사용하거나 --port 8766으로 실행하세요.")
        return 1
    monitor.start()
    url = f"http://127.0.0.1:{server.server_port}/"
    print("자비스 사무실 " + VERSION)
    print("브라우저 주소: " + url)
    print("로컬 기록 읽기 전용 · 대화 본문/명령/코드 전송 없음")
    print("종료: 이 창에서 Ctrl+C를 누르세요.")
    if not args.no_browser:
        # Launching a local URL does not send session records anywhere.
        try:
            webbrowser.open(url)
        except Exception:
            print("브라우저에서 위 주소를 직접 열어 주세요.")
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print("\n자비스 사무실을 종료합니다.")
    finally:
        monitor.stop()
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
