"""Read-only, experimental adapters for Codex activity records.

No command, prompt, path, tool result, message, or reasoning text is returned.
The mutable context stores only identifiers, classifications, and bounded dedup
keys. This module performs no file access and never starts Codex or an API call.

Rollout JSONL is NOT a stable interface. The implementation was checked against
openai/codex main on 2026-10-20 (8196bcdc189ad2c189d631b321fa54b8e09b9bb0):
  codex-rs/history/src/rollout_payload.rs
  codex-rs/rollout/src/policy.rs
  codex-rs/protocol/src/{protocol,models,items}.rs
See also https://learn.chatgpt.com/docs/hooks and
https://learn.chatgpt.com/docs/non-interactive-mode.

Stored rollouts omit many transient begin/end events. In particular, do not
expect exec_command_begin or collab_agent_spawn_begin to exist on disk. Prefer
response_item calls/results, explicit task lifecycle events, and the newer
event_msg.item_completed form. Completed items describe observed past work;
their presence does not prove that the action is still running.

Identity contract: session_id/agent_id identify the current thread, parent_id
identifies its parent thread. session_meta.session_id (the session-tree root in
newer versions) is kept separately as context['root_session_id']. Parent/child
files need server-level dedup by thread id: a parent-confirmed child start and
the child's task_started are observations of the same agent, not two agents.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any

_ID = re.compile(r"[A-Za-z0-9_.:-]{1,160}\Z")
_MAX_SEEN = 2048
_MAX_CALLS = 512
_MAX_RESULT = 65536
_LABELS = {
    "read": "자료 읽기", "write": "파일 수정", "execute": "명령 실행",
    "search": "정보 검색", "plan": "작업 계획", "ask": "사용자 확인 대기",
    "delegate": "협업 작업 요청", "start": "작업 시작", "complete": "작업 완료",
    "error": "작업 오류", "idle": "다음 작업 대기",
}


def _identifier(value: Any) -> str | None:
    return value if isinstance(value, str) and _ID.fullmatch(value) else None


def _timestamp(value: Any) -> str | None:
    if not isinstance(value, str) or len(value) > 45:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return None
    return parsed.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _state(context: dict) -> dict:
    value = context.get("_codex_adapter")
    if not isinstance(value, dict):
        value = {"seen": {}, "calls": {}, "children": {}}
        context["_codex_adapter"] = value
    return value


def _once(state: dict, key: str | None) -> bool:
    if key is None:
        return True
    seen = state["seen"]
    if key in seen:
        return False
    seen[key] = True
    if len(seen) > _MAX_SEEN:
        del seen[next(iter(seen))]
    return True


def _event(context: dict, kind: str, ts: str | None, tool: str = "",
           label: str | None = None, child: str | None = None) -> dict | None:
    current = _identifier(context.get("session_id")) or _identifier(context.get("file_id"))
    identity = child or current
    if identity is None:
        return None
    parent = current if child else _identifier(context.get("parent_session_id"))
    return {
        "session_id": identity,
        "agent_id": identity,
        "parent_id": parent,
        "provider": "codex",
        "kind": kind,
        "label": label or _LABELS[kind],
        "timestamp": ts,
        "tool": _identifier(tool) or "",
    }


def _emit(context: dict, *args: Any, **kwargs: Any) -> list[dict]:
    event = _event(context, *args, **kwargs)
    return [event] if event is not None else []


def _tool_kind(tool: str) -> str:
    """Classify only a tool's identifier; never inspect command or prompt text."""
    name = tool.lower().rsplit(".", 1)[-1]
    if name in {"spawn_agent", "agent", "task", "send_message", "send_input", "followup_task"}:
        return "delegate"
    if name in {"request_user_input", "ask_user", "askuserquestion", "request_permissions"}:
        return "ask"
    if name in {"update_plan", "plan", "enterplanmode", "exitplanmode"}:
        return "plan"
    if name in {"apply_patch", "write_file", "edit_file", "write", "edit", "multiedit"}:
        return "write"
    if name in {"read", "read_file", "view_image", "read_mcp_resource", "get_file"}:
        return "read"
    if name in {"wait", "wait_agent", "sleep"}:
        return "idle"
    if any(word in name for word in ("search", "webfetch", "web_fetch")):
        return "search"
    if any(word in name for word in ("_read_", "_get_document", "_get_file", "_fetch_file")):
        return "read"
    return "execute"


def _is_spawn(tool: str) -> bool:
    return tool.lower().rsplit(".", 1)[-1] in {"spawn_agent", "agent", "task"}


def _call(context: dict, state: dict, payload: dict, ts: str | None) -> list[dict]:
    tool = _identifier(payload.get("name"))
    if not tool:
        return []
    call_id = _identifier(payload.get("call_id")) or _identifier(payload.get("id"))
    if not _once(state, f"call:{call_id}" if call_id else None):
        return []
    kind = _tool_kind(tool)
    if call_id:
        state["calls"][call_id] = {"tool": tool, "kind": kind}
        if len(state["calls"]) > _MAX_CALLS:
            del state["calls"][next(iter(state["calls"]))]
    return _emit(context, kind, ts, tool)


def _result_objects(value: Any) -> list[dict]:
    """Read bounded structured result envelopes, without retaining raw content."""
    if isinstance(value, str):
        if len(value) > _MAX_RESULT:
            return []
        try:
            value = json.loads(value)
        except (ValueError, RecursionError):
            return []
    if isinstance(value, dict):
        result = [value]
        for key in ("structuredContent", "result"):
            nested = value.get(key)
            if isinstance(nested, dict):
                result.append(nested)
        content = value.get("content")
        if isinstance(content, list):
            result.extend(_result_objects(content))
        return result
    if isinstance(value, list):
        result = []
        for part in value[:16]:
            if isinstance(part, dict) and part.get("type") in {"text", "output_text", "input_text"}:
                text = part.get("text")
                if isinstance(text, str) and len(text) <= _MAX_RESULT:
                    try:
                        parsed = json.loads(text)
                    except (ValueError, RecursionError):
                        continue
                    if isinstance(parsed, dict):
                        result.append(parsed)
        return result
    return []


def _failed(value: dict) -> bool:
    status = value.get("status")
    return (value.get("isError") is True or value.get("success") is False
            or (isinstance(status, str) and status in {"failed", "errored", "declined"})
            or bool(value.get("error"))
            or (isinstance(value.get("exit_code"), int)
                and not isinstance(value.get("exit_code"), bool) and value["exit_code"] != 0))


def _child_start(context: dict, state: dict, child: str, ts: str | None, tool: str) -> list[dict]:
    if child == context.get("session_id") or child in state["children"]:
        return []
    state["children"][child] = True
    if len(state["children"]) > _MAX_CALLS:
        del state["children"][next(iter(state["children"]))]
    return _emit(context, "start", ts, tool, label="협업 에이전트 합류", child=child)


def _output(context: dict, state: dict, payload: dict, ts: str | None) -> list[dict]:
    call_id = _identifier(payload.get("call_id")) or _identifier(payload.get("id"))
    call = state["calls"].get(call_id)
    if not call or not _once(state, f"result:{call_id}"):
        return []
    objects = _result_objects(payload.get("output"))
    if any(_failed(obj) for obj in objects):
        return _emit(context, "error", ts, call["tool"], label="도구 작업 오류")
    events = _emit(context, "idle", ts, call["tool"], label="도구 응답 수신")
    if _is_spawn(call["tool"]):
        for obj in objects:
            child = next((_identifier(obj.get(key)) for key in ("agent_id", "thread_id", "new_thread_id")
                          if _identifier(obj.get(key))), None)
            if child:
                events.extend(_child_start(context, state, child, ts, call["tool"]))
                break
    return events


def _item_completed(context: dict, state: dict, payload: dict, ts: str | None) -> list[dict]:
    item = payload.get("item")
    if not isinstance(item, dict) or not isinstance(item.get("type"), str):
        return []
    item_type = re.sub(r"[^a-z]", "", item["type"].lower())
    item_id = _identifier(item.get("id"))
    if item_type in {"agentmessage", "reasoning"} and not _once(state, f"content-item:{item_id}" if item_id else None):
        return []
    phase = "started" if payload.get("type") == "item.started" else "completed"
    if not _once(state, f"item:{phase}:{item_id}" if item_id else None):
        return []
    if item_type == "functioncalloutput":
        return _output(context, state, item, ts)
    if item_type == "subagentactivity":
        child = _identifier(item.get("agent_thread_id"))
        if not child:
            return []
        activity = item.get("kind")
        if activity == "started":
            return _child_start(context, state, child, ts, "spawn_agent")
        if activity == "completed":
            return _emit(context, "complete", ts, label="협업 작업 완료", child=child)
        if activity == "interrupted":
            return _emit(context, "idle", ts, label="협업 작업 중단", child=child)
        return []
    if item_type in {"collabagenttoolcall", "collaborationtoolcall"}:
        tool = _identifier(item.get("tool")) or ""
        if _failed(item):
            return _emit(context, "error", ts, tool, label="협업 요청 오류")
        events = _emit(context, "delegate", ts, tool)
        if _is_spawn(tool) and item.get("status") == "completed":
            children = item.get("receiver_thread_ids", [])
            if isinstance(children, list):
                for value in children[:32]:
                    child = _identifier(value)
                    if child:
                        events.extend(_child_start(context, state, child, ts, tool))
        return events
    kind = {
        "commandexecution": "execute", "filechange": "write", "websearch": "search",
        "imageview": "read", "plan": "plan", "reasoning": "plan",
        "agentmessage": "write", "contextcompaction": "plan",
    }.get(item_type)
    tool = ""
    if item_type in {"mcptoolcall", "dynamictoolcall"}:
        tool = _identifier(item.get("tool")) or ""
        kind = _tool_kind(tool) if tool else "execute"
    if not kind:
        return []
    if _failed(item):
        return _emit(context, "error", ts, tool, label="도구 작업 오류")
    # A matching raw call output already supplied its completion observation.
    if item_id and f"result:{item_id}" in state["seen"]:
        return []
    if item_type == "commandexecution" and phase == "completed":
        # A completed command is a terminal observation, not a fresh start.
        return _emit(context, "idle", ts, tool, label="도구 작업 종료")
    label = "답변 작성" if item_type == "agentmessage" else None
    return _emit(context, kind, ts, tool, label=label)


def _session_meta(context: dict, payload: dict) -> None:
    thread_id = _identifier(payload.get("id"))
    if thread_id:
        context["session_id"] = thread_id
    root = _identifier(payload.get("session_id"))
    if root:
        context["root_session_id"] = root
    parent = _identifier(payload.get("parent_thread_id"))
    source = payload.get("source")
    if isinstance(source, dict) and isinstance(source.get("subagent"), dict):
        context["is_subagent"] = True
        spawn = source["subagent"].get("thread_spawn")
        if isinstance(spawn, dict):
            parent = parent or _identifier(spawn.get("parent_thread_id"))
    if parent:
        context["is_subagent"] = True
        context["parent_session_id"] = parent


def parse_codex(record: dict, context: dict) -> list[dict]:
    """Return safe activity observations; unknown or malformed schemas return [].

    context is per physical file. Callers should reset it when that file is
    replaced/truncated and merge agent identity across parent/child files.
    No record content is retained in context or returned to the browser.
    """
    if not isinstance(record, dict) or not isinstance(context, dict):
        return []
    state = _state(context)
    ts = _timestamp(record.get("timestamp"))
    record_type = record.get("type")
    if not isinstance(record_type, str):
        return []
    payload = record.get("payload")
    if record_type == "session_meta" and isinstance(payload, dict):
        _session_meta(context, payload)
        return []  # Discovery alone does not prove active work.
    ordinal = record.get("ordinal")
    if isinstance(ordinal, int) and not isinstance(ordinal, bool):
        if not _once(state, f"ordinal:{ordinal}"):
            return []
    if record_type == "response_item" and isinstance(payload, dict):
        kind = payload.get("type")
        if not isinstance(kind, str):
            return []
        if kind in {"function_call", "custom_tool_call"}:
            return _call(context, state, payload, ts)
        if kind in {"function_call_output", "custom_tool_call_output"}:
            return _output(context, state, payload, ts)
        if kind in {"web_search_call", "tool_search_call"}:
            return _emit(context, "search", ts, kind)
        if kind == "local_shell_call":
            return _emit(context, "execute", ts, "local_shell_call")
        if kind == "message" and payload.get("role") == "assistant":
            item_id = _identifier(payload.get("id"))
            if not _once(state, f"content-item:{item_id}" if item_id else None):
                return []
            return _emit(context, "write", ts, label="답변 작성")
        if kind == "reasoning":
            item_id = _identifier(payload.get("id"))
            if not _once(state, f"content-item:{item_id}" if item_id else None):
                return []
            return _emit(context, "plan", ts, label="작업 검토")
        return []
    if record_type == "event_msg" and isinstance(payload, dict):
        event_type = payload.get("type")
        if not isinstance(event_type, str):
            return []
        turn_id = _identifier(payload.get("turn_id"))
        if event_type in {"task_started", "turn_started"}:
            if _once(state, f"turn-start:{turn_id}" if turn_id else None):
                return _emit(context, "start", ts)
            return []
        if event_type in {"task_complete", "turn_complete"}:
            if not _once(state, f"turn-end:{turn_id}" if turn_id else None):
                return []
            return _emit(context, "error" if payload.get("error") else "complete", ts)
        if event_type == "turn_aborted":
            return _emit(context, "idle", ts, label="작업 중단")
        if event_type == "error":
            return _emit(context, "error", ts)
        if event_type in {"request_user_input", "exec_approval_request", "apply_patch_approval_request"}:
            return _emit(context, "ask", ts)
        if event_type == "item_completed":
            return _item_completed(context, state, payload, ts)
        return []
    # Official codex exec --json output, when the caller explicitly supplies it.
    # Reading these records does not execute codex or alter an interactive run.
    if record_type == "thread.started":
        thread_id = _identifier(record.get("thread_id"))
        if thread_id:
            context["session_id"] = thread_id
        return []
    if record_type == "turn.started":
        return _emit(context, "start", ts)
    if record_type == "turn.completed":
        return _emit(context, "complete", ts)
    if record_type in {"turn.failed", "error"}:
        return _emit(context, "error", ts)
    if record_type in {"item.started", "item.completed"}:
        return _item_completed(context, state, record, ts)
    return []
