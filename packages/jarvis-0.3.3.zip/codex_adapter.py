"""Read-only, experimental adapters for Codex activity records.

No command, prompt, path, tool result, message, or reasoning text is returned.
The opt-in Local Work metadata reader also returns the bounded thread.name;
it never substitutes a preview, message, or inferred title for that metadata.
The mutable context stores only identifiers, classifications, and bounded dedup
keys. The parse_codex function performs no I/O. The opt-in Local Work classes
below read approved receipt files and own a metadata-only Codex app-server.

Rollout JSONL is NOT a stable interface. The implementation was checked against
openai/codex main on 2026-10-20 (8196bcdc189ad2c189d631b321fa54b8e09b9bb0):
  codex-rs/history/src/rollout_payload.rs
  codex-rs/rollout/src/policy.rs
  codex-rs/protocol/src/{protocol,models,items}.rs
See also https://learn.chatgpt.com/docs/hooks and
https://learn.chatgpt.com/docs/non-interactive-mode.

Stored rollouts omit many transient begin/end events. In particular, do not
expect exec_command_begin or collab_agent_spawn_begin to exist on disk. Prefer
response_item calls/results, explicit task lifecycle events, and the newer
event_msg.item_completed form. Completed items describe observed past work;
their presence does not prove that the action is still running.

Identity contract: session_id/agent_id identify the current thread, parent_id
identifies its parent thread. session_meta.session_id (the session-tree root in
newer versions) is kept separately as context['root_session_id']. Parent/child
files need server-level dedup by thread id: a parent-confirmed child start and
the child's task_started are observations of the same agent, not two agents.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any

_ID = re.compile(r"[A-Za-z0-9_.:-]{1,160}\Z")
_MAX_SEEN = 2048
_MAX_CALLS = 512
_MAX_RESULT = 65536
_LABELS = {
    "read": "자료 읽기", "write": "파일 수정", "execute": "명령 실행",
    "search": "정보 검색", "plan": "작업 계획", "ask": "사용자 확인 대기",
    "delegate": "협업 작업 요청", "start": "작업 시작", "complete": "작업 완료",
    "error": "작업 오류", "idle": "다음 작업 대기",
}


def _identifier(value: Any) -> str | None:
    return value if isinstance(value, str) and _ID.fullmatch(value) else None


def _timestamp(value: Any) -> str | None:
    if not isinstance(value, str) or len(value) > 45:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return None
    return parsed.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _state(context: dict) -> dict:
    value = context.get("_codex_adapter")
    if not isinstance(value, dict):
        value = {"seen": {}, "calls": {}, "children": {}}
        context["_codex_adapter"] = value
    return value


def _once(state: dict, key: str | None) -> bool:
    if key is None:
        return True
    seen = state["seen"]
    if key in seen:
        return False
    seen[key] = True
    if len(seen) > _MAX_SEEN:
        del seen[next(iter(seen))]
    return True


def _event(context: dict, kind: str, ts: str | None, tool: str = "",
           label: str | None = None, child: str | None = None) -> dict | None:
    current = _identifier(context.get("session_id")) or _identifier(context.get("file_id"))
    identity = child or current
    if identity is None:
        return None
    parent = current if child else _identifier(context.get("parent_session_id"))
    return {
        "session_id": identity,
        "agent_id": identity,
        "parent_id": parent,
        "provider": "codex",
        "kind": kind,
        "label": label or _LABELS[kind],
        "timestamp": ts,
        "tool": _identifier(tool) or "",
    }


def _emit(context: dict, *args: Any, **kwargs: Any) -> list[dict]:
    event = _event(context, *args, **kwargs)
    return [event] if event is not None else []


def _tool_kind(tool: str) -> str:
    """Classify only a tool's identifier; never inspect command or prompt text."""
    name = tool.lower().rsplit(".", 1)[-1]
    if name in {"spawn_agent", "agent", "task", "send_message", "send_input", "followup_task"}:
        return "delegate"
    if name in {"request_user_input", "ask_user", "askuserquestion", "request_permissions"}:
        return "ask"
    if name in {"update_plan", "plan", "enterplanmode", "exitplanmode"}:
        return "plan"
    if name in {"apply_patch", "write_file", "edit_file", "write", "edit", "multiedit"}:
        return "write"
    if name in {"read", "read_file", "view_image", "read_mcp_resource", "get_file"}:
        return "read"
    if name in {"wait", "wait_agent", "sleep"}:
        return "idle"
    if any(word in name for word in ("search", "webfetch", "web_fetch")):
        return "search"
    if any(word in name for word in ("_read_", "_get_document", "_get_file", "_fetch_file")):
        return "read"
    return "execute"


def _is_spawn(tool: str) -> bool:
    return tool.lower().rsplit(".", 1)[-1] in {"spawn_agent", "agent", "task"}


def _call(context: dict, state: dict, payload: dict, ts: str | None) -> list[dict]:
    tool = _identifier(payload.get("name"))
    if not tool:
        return []
    call_id = _identifier(payload.get("call_id")) or _identifier(payload.get("id"))
    if not _once(state, f"call:{call_id}" if call_id else None):
        return []
    kind = _tool_kind(tool)
    if call_id:
        state["calls"][call_id] = {"tool": tool, "kind": kind}
        if len(state["calls"]) > _MAX_CALLS:
            del state["calls"][next(iter(state["calls"]))]
    return _emit(context, kind, ts, tool)


def _result_objects(value: Any) -> list[dict]:
    """Read bounded structured result envelopes, without retaining raw content."""
    if isinstance(value, str):
        if len(value) > _MAX_RESULT:
            return []
        try:
            value = json.loads(value)
        except (ValueError, RecursionError):
            return []
    if isinstance(value, dict):
        result = [value]
        for key in ("structuredContent", "result"):
            nested = value.get(key)
            if isinstance(nested, dict):
                result.append(nested)
        content = value.get("content")
        if isinstance(content, list):
            result.extend(_result_objects(content))
        return result
    if isinstance(value, list):
        result = []
        for part in value[:16]:
            if isinstance(part, dict) and part.get("type") in {"text", "output_text", "input_text"}:
                text = part.get("text")
                if isinstance(text, str) and len(text) <= _MAX_RESULT:
                    try:
                        parsed = json.loads(text)
                    except (ValueError, RecursionError):
                        continue
                    if isinstance(parsed, dict):
                        result.append(parsed)
        return result
    return []


# Local Work is an explicitly registered product mode, not a deduction from
# Codex's backing kind, model, folder, originator, or an open window. Keep the
# original rollout parser independent of this opt-in protocol-1 extension.
import collections as _lw_collections
import copy as _lw_copy
import hashlib as _lw_hashlib
import math as _lw_math
import os as _lw_os
from pathlib import Path as _LWPath
import queue as _lw_queue
import shutil as _lw_shutil
import subprocess as _lw_subprocess
import threading as _lw_threading
import time as _lw_time
import unicodedata as _lw_unicode

_LW_TERMINAL = frozenset({"completed", "failed", "interrupted"})
_LW_EVENTS = frozenset({"SessionStart", "UserPromptSubmit", "PreToolUse", "PostToolUse",
                        "PermissionRequest", "Stop", "Interrupt", "SessionEnd"})
_LW_SOURCE_KINDS = ["cli", "vscode", "exec", "appServer", "subAgent", "subAgentReview",
                    "subAgentCompact", "subAgentThreadSpawn", "subAgentOther", "unknown"]
_LW_ID = re.compile(r"[A-Za-z0-9_.:~-]{1,256}\Z")
_LW_TITLE_LIMIT = 240


def _lw_title_metadata(value):
    """Allow only the explicit thread.name, as bounded display text."""
    if value is None:
        return {"taskTitle": None, "titleStatus": "empty", "titleTruncated": False}
    if not isinstance(value, str):
        return {"taskTitle": None, "titleStatus": "invalid", "titleTruncated": False}
    # Bound work even for a malformed metadata string. Formatting controls and
    # isolated surrogates cannot affect the surrounding task labels or JSON.
    text = "".join(" " if char.isspace() else char for char in value[:4096]
                   if char.isspace() or _lw_unicode.category(char) not in {"Cc", "Cf", "Cs"})
    text = " ".join(text.split())
    truncated = len(value) > 4096 or len(text) > _LW_TITLE_LIMIT
    title = text[:_LW_TITLE_LIMIT].strip()
    return {"taskTitle": title or None, "titleStatus": "valid" if title else "empty",
            "titleTruncated": truncated}


def _lw_sha(value):
    return _lw_hashlib.sha256(str(value).encode("utf-8")).hexdigest()


def _lw_norm(value):
    return _lw_os.path.normcase(_lw_os.path.abspath(str(value)))


def _lw_iso(value):
    return datetime.fromtimestamp(value, timezone.utc).isoformat()


def _lw_time_value(value):
    if isinstance(value, str):
        try:
            stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return stamp.timestamp() if stamp.tzinfo is not None else None
        except (ValueError, OverflowError):
            return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value) if _lw_math.isfinite(value) and 0 <= value <= 253402300799 else None
    return None


def _lw_terminal_time_valid(started_at, completed_at):
    # A separate app-server's persisted status can disagree with the live
    # owner. A label without a real closure time is not authoritative evidence
    # of termination; a null timestamp alone does not establish the cause.
    return started_at is not None and completed_at is not None and completed_at >= started_at


def _lw_plain_directory(value):
    path = _LWPath(value).absolute()
    try:
        return path.is_dir() and not path.is_symlink() and path.resolve() == path
    except (OSError, RuntimeError):
        return False


def _lw_binding(value):
    if not isinstance(value, dict) or value.get("confirmedLocalWork") is not True:
        raise ValueError("Local Work 출처 확인이 필요합니다.")
    for key in ("id", "threadId"):
        if not isinstance(value.get(key), str) or not _LW_ID.fullmatch(value[key]):
            raise ValueError("Local Work 연결 식별자를 확인하세요.")
    cwd = value.get("cwd")
    if not isinstance(cwd, str) or len(cwd) > 2048 or not _LWPath(cwd).is_absolute():
        raise ValueError("Local Work 기본 폴더를 확인하세요.")
    session = value.get("sessionId", value["threadId"])
    if not isinstance(session, str) or not _LW_ID.fullmatch(session):
        raise ValueError("Local Work 세션 식별자를 확인하세요.")
    receipt_dir = value.get("receiptDir") or str(_LWPath(cwd) / "observations")
    if not isinstance(receipt_dir, str) or len(receipt_dir) > 2048 or not _LWPath(receipt_dir).is_absolute():
        raise ValueError("Local Work 관측 폴더를 확인하세요.")
    return {"id": value["id"], "threadId": value["threadId"], "sessionId": session,
            "cwd": str(_LWPath(cwd).absolute()), "receiptDir": str(_LWPath(receipt_dir).absolute()),
            "name": str(value.get("name") or "Local Work")[:80], "confirmedLocalWork": True}


def _lw_runtime_candidate(value):
    """Accept only an existing app-managed codex.exe, never a supplied command."""
    if not value:
        return None
    path = _LWPath(value).absolute()
    local = _LWPath(_lw_os.environ.get("LOCALAPPDATA", "")) / "OpenAI" / "Codex" / "bin"
    try:
        if path.name.lower() != "codex.exe" or not path.is_file() or path.is_symlink() or path.resolve() != path:
            return None
        relative = path.relative_to(local.absolute())
        if len(relative.parts) != 2 or not re.fullmatch(r"[A-Za-z0-9_-]{8,80}", relative.parts[0]):
            return None
        return path
    except (ValueError, OSError, RuntimeError):
        return None


def find_local_work_runtime():
    """Find the existing desktop-managed runtime. No install, login, or execution."""
    candidate = _lw_runtime_candidate(_lw_shutil.which("codex"))
    if candidate:
        return candidate
    root = _LWPath(_lw_os.environ.get("LOCALAPPDATA", "")) / "OpenAI" / "Codex" / "bin"
    choices = []
    try:
        with _lw_os.scandir(root) as entries:
            for index, entry in enumerate(entries):
                if index >= 128:
                    break
                if entry.is_dir(follow_symlinks=False):
                    path = _lw_runtime_candidate(_LWPath(entry.path) / "codex.exe")
                    if path:
                        choices.append((path.stat().st_mtime, str(path), path))
    except OSError:
        return None
    return max(choices)[2] if choices else None


class LocalWorkRPCError(RuntimeError):
    """Only a fixed diagnostic code is exposed, never a raw server error body."""
    def __init__(self, code):
        self.code = code
        super().__init__(code)


class LocalWorkRPCClient:
    """Owned stdio server with a fixed metadata-only method surface.

    read_binding returns identifiers/status scalars only. All command/message/
    result bodies returned by the protocol are dropped in memory. It never
    attaches, resumes, starts, steers, interrupts, or modifies a Work task.
    """
    def __init__(self, runtime_path=None, timeout=4.0, cwd=None):
        self.runtime_path = _lw_runtime_candidate(runtime_path) if runtime_path else find_local_work_runtime()
        self.timeout = max(.2, min(float(timeout), 10.0))
        self.cwd = str(cwd) if cwd else None
        self._process = None
        self._job = self._kernel = None
        self._responses = _lw_queue.Queue(maxsize=32)
        self._request_lock = _lw_threading.RLock()
        self._next_id = 0
        self._closed = False

    @staticmethod
    def _windows_job(process):
        import ctypes
        from ctypes import wintypes
        class Basic(ctypes.Structure):
            _fields_ = [("a", ctypes.c_longlong), ("b", ctypes.c_longlong), ("flags", wintypes.DWORD),
                        ("min", ctypes.c_size_t), ("max", ctypes.c_size_t), ("count", wintypes.DWORD),
                        ("affinity", ctypes.c_size_t), ("priority", wintypes.DWORD), ("schedule", wintypes.DWORD)]
        class IO(ctypes.Structure):
            _fields_ = [(name, ctypes.c_ulonglong) for name in ("a", "b", "c", "d", "e", "f")]
        class Limits(ctypes.Structure):
            _fields_ = [("basic", Basic), ("io", IO), ("a", ctypes.c_size_t),
                        ("b", ctypes.c_size_t), ("c", ctypes.c_size_t), ("d", ctypes.c_size_t)]
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
        kernel.CreateJobObjectW.restype = wintypes.HANDLE
        kernel.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        kernel.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        job = kernel.CreateJobObjectW(None, None)
        limits = Limits()
        limits.basic.flags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if not job:
            raise LocalWorkRPCError("processOwnershipUnavailable")
        if not kernel.SetInformationJobObject(job, 9, ctypes.byref(limits), ctypes.sizeof(limits)) or not kernel.AssignProcessToJobObject(job, wintypes.HANDLE(int(process._handle))):
            kernel.CloseHandle(job)
            raise LocalWorkRPCError("processOwnershipUnavailable")
        return kernel, job

    def _start(self, cwd, deadline):
        if self._closed:
            raise LocalWorkRPCError("readerClosed")
        if self._process is not None and self._process.poll() is None:
            return
        if self.runtime_path is None:
            raise LocalWorkRPCError("runtimeUnavailable")
        self._stop_process()
        self._responses = _lw_queue.Queue(maxsize=32)
        try:
            process = _lw_subprocess.Popen([str(self.runtime_path), "app-server"],
                cwd=self.cwd or cwd, shell=False, stdin=_lw_subprocess.PIPE,
                stdout=_lw_subprocess.PIPE, stderr=_lw_subprocess.DEVNULL,
                creationflags=getattr(_lw_subprocess, "CREATE_NO_WINDOW", 0),
                start_new_session=_lw_os.name != "nt")
            self._process = process
            if _lw_os.name == "nt":
                self._kernel, self._job = self._windows_job(process)
        except (OSError, LocalWorkRPCError):
            self._stop_process()
            raise LocalWorkRPCError("runtimeUnavailable") from None
        responses = self._responses
        def receive():
            try:
                while True:
                    line = process.stdout.readline(2 * 1024 * 1024 + 1)
                    if not line:
                        break
                    if len(line) > 2 * 1024 * 1024:
                        responses.put_nowait({"_readerError": "responseTooLarge"})
                        break
                    try:
                        value = json.loads(line)
                    except (ValueError, UnicodeError):
                        continue
                    if isinstance(value, dict) and "id" in value and ("result" in value or "error" in value):
                        responses.put_nowait(value)
            except (OSError, ValueError, _lw_queue.Full):
                pass
            try:
                responses.put_nowait({"_readerError": "serverClosed"})
            except _lw_queue.Full:
                pass
        _lw_threading.Thread(target=receive, name="local-work-rpc-metadata", daemon=True).start()
        self._call("initialize", {"clientInfo": {"name": "jarvis_local_work_read_only", "version": "0.3.1"}}, deadline)
        self._call("initialized", {}, deadline, notification=True)

    def _call(self, method, params, deadline, notification=False):
        if method not in {"initialize", "initialized", "thread/list", "thread/read", "thread/turns/list", "thread/items/list"}:
            raise LocalWorkRPCError("methodNotAllowed")
        if self._closed or self._process is None or self._process.poll() is not None:
            raise LocalWorkRPCError("serverClosed")
        self._next_id += 1
        request_id = self._next_id
        value = {"method": method, "params": params}
        if not notification:
            value["id"] = request_id
        try:
            self._process.stdin.write((json.dumps(value) + "\n").encode("utf-8"))
            self._process.stdin.flush()
        except (OSError, ValueError):
            raise LocalWorkRPCError("serverClosed") from None
        if notification:
            return {}
        while not self._closed and _lw_time.monotonic() < deadline:
            try:
                response = self._responses.get(timeout=min(.1, max(.001, deadline-_lw_time.monotonic())))
            except _lw_queue.Empty:
                continue
            if "_readerError" in response:
                raise LocalWorkRPCError(response["_readerError"])
            if response.get("id") != request_id:
                continue
            if "error" in response:
                raise LocalWorkRPCError("protocolError")
            result = response.get("result")
            if not isinstance(result, dict):
                raise LocalWorkRPCError("invalidMetadata")
            return result
        raise LocalWorkRPCError("readerClosed" if self._closed else "timeout")

    def list_exact_cwd(self, cwd):
        """Optional exact-cwd check, never a broad enumeration or source claim."""
        if not isinstance(cwd, str) or not _LWPath(cwd).is_absolute():
            raise LocalWorkRPCError("invalidCwd")
        with self._request_lock:
            deadline = _lw_time.monotonic() + self.timeout
            try:
                self._start(cwd, deadline)
                result = self._call("thread/list", {"cwd": cwd, "sourceKinds": _LW_SOURCE_KINDS,
                    "useStateDbOnly": True, "archived": False, "limit": 50}, deadline)
                candidates = []
                folder_name = _LWPath(cwd).name or "Local Work"
                for row in result.get("data", [])[:50]:
                    if not isinstance(row, dict) or not isinstance(row.get("id"), str) or _lw_norm(row.get("cwd", "")) != _lw_norm(cwd):
                        continue
                    title = _lw_title_metadata(row.get("name"))
                    candidates.append({"threadId": row["id"],
                        "name": title["taskTitle"] or "작업 " + row["id"][:8],
                        "folderName": folder_name, **title,
                        "titleSource": "thread-name" if title["taskTitle"] else "fallback",
                        "titleState": "current" if title["taskTitle"] else "missing",
                        "updatedAt": None})
                return {"threadIds": [row["threadId"] for row in candidates], "candidates": candidates,
                    "truncated": result.get("nextCursor") is not None}
            except LocalWorkRPCError:
                self._stop_process()
                raise

    def read_binding(self, binding, include_tool_metadata=True, timeout=None):
        binding = _lw_binding(binding)
        with self._request_lock:
            deadline = _lw_time.monotonic() + (self.timeout if timeout is None else min(self.timeout, max(.01, float(timeout))))
            try:
                self._start(binding["cwd"], deadline)
                result = self._call("thread/read", {"threadId": binding["threadId"], "includeTurns": False}, deadline)
                thread = result.get("thread", {})
                if not isinstance(thread, dict) or thread.get("id") != binding["threadId"] or _lw_norm(thread.get("cwd", "")) != _lw_norm(binding["cwd"]):
                    raise LocalWorkRPCError("identityMismatch")
                status = thread.get("status")
                status = status if isinstance(status, dict) else {}
                flags = status.get("activeFlags", [])
                flags = flags if isinstance(flags, list) else []
                active_flags = [flag for flag in flags
                                if flag in ("waitingOnApproval", "waitingOnUserInput")]
                turns_result = self._call("thread/turns/list", {"threadId": binding["threadId"],
                    "itemsView": "notLoaded", "limit": 5, "sortDirection": "desc"}, deadline)
                turns = []
                for turn in turns_result.get("data", [])[:5]:
                    if not isinstance(turn, dict) or not isinstance(turn.get("id"), str) or not _LW_ID.fullmatch(turn["id"]):
                        continue
                    outcome = turn.get("status")
                    if outcome not in _LW_TERMINAL | {"inProgress"}:
                        outcome = "unknown"
                    reported_outcome = outcome
                    started_at = _lw_time_value(turn.get("startedAt"))
                    completed_at = _lw_time_value(turn.get("completedAt"))
                    verified_terminal = outcome in _LW_TERMINAL and _lw_terminal_time_valid(started_at, completed_at)
                    if outcome in _LW_TERMINAL and not verified_terminal:
                        outcome = "unknown"
                    turns.append({"id": turn["id"], "status": outcome, "reportedStatus": reported_outcome,
                        "startedAt": started_at, "completedAt": completed_at,
                        "terminalTimestampVerified": verified_terminal,
                        "errorPresent": turn.get("error") is not None})
                metadata = {"ok": True, "checkedAt": _lw_time.time(), "threadId": binding["threadId"], "cwd": binding["cwd"],
                    **_lw_title_metadata(thread.get("name")),
                    "threadStatus": status.get("type") if status.get("type") in {"active", "idle", "notLoaded", "systemError"} else "unknown",
                    "activeFlags": active_flags, "turns": turns, "tools": [],
                    "toolMetadataAvailable": False, "toolMetadataTruncated": False}
                if include_tool_metadata and turns and _lw_time.monotonic() < deadline:
                    try:
                        items = self._call("thread/items/list", {"threadId": binding["threadId"], "turnId": turns[0]["id"],
                            "limit": 50, "sortDirection": "desc"}, deadline)
                        metadata["toolMetadataAvailable"] = True
                        metadata["toolMetadataTruncated"] = items.get("nextCursor") is not None
                        for entry in items.get("data", [])[:50]:
                            if not isinstance(entry, dict) or entry.get("turnId") != turns[0]["id"]:
                                continue
                            item = entry.get("item", {})
                            if not isinstance(item, dict) or item.get("type") not in {"commandExecution", "mcpToolCall"} or not isinstance(item.get("id"), str):
                                continue
                            tool_status = item.get("status")
                            if tool_status not in {"inProgress", "completed", "failed", "declined"}:
                                continue
                            code = item.get("exitCode")
                            code = code if isinstance(code, int) and not isinstance(code, bool) else None
                            metadata["tools"].append({"id": item["id"], "turnId": turns[0]["id"],
                                "type": item["type"], "status": tool_status, "exitCode": code,
                                "errorPresent": item.get("error") is not None,
                                "completedAt": (_lw_time_value(entry.get("completedAtMs"))/1000
                                    if _lw_time_value(entry.get("completedAtMs")) is not None else None)})
                    except LocalWorkRPCError:
                        # Turn status remains valid if optional item metadata is unavailable.
                        self._stop_process()
                return metadata
            except LocalWorkRPCError:
                self._stop_process()
                raise
            except (TypeError, ValueError, KeyError, OverflowError):
                self._stop_process()
                raise LocalWorkRPCError("invalidMetadata") from None

    def _stop_process(self):
        process, job, kernel = self._process, self._job, self._kernel
        self._process = self._job = self._kernel = None
        if process is None:
            return
        try:
            process.stdin.close()
        except (OSError, ValueError, AttributeError):
            pass
        try:
            process.wait(timeout=.3)
        except _lw_subprocess.TimeoutExpired:
            pass
        if job is not None:
            kernel.CloseHandle(job)
        elif process.poll() is None:
            if _lw_os.name != "nt":
                import signal
                try:
                    _lw_os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            else:
                process.kill()
        try:
            process.wait(timeout=1)
        except _lw_subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=1)
        try:
            process.stdout.close()
        except (OSError, ValueError):
            pass

    def close(self):
        self._closed = True
        self._stop_process()


class LocalWorkObserver:
    """Poll explicitly UI-confirmed Local Work bindings; snapshot is I/O-free.

    Receipt silence never means completion/disconnection. Stop alone never
    means success. A failed tool and a completed encompassing turn coexist.
    Binding source confirmation is manual; state observations are automatic.
    """
    def __init__(self, bindings, rpc_client=None, clock=None):
        self.bindings = [_lw_binding(binding) for binding in bindings]
        if (len(self.bindings) > 16 or len({b["id"] for b in self.bindings}) != len(self.bindings)
                or len({b["threadId"] for b in self.bindings}) != len(self.bindings)):
            raise ValueError("Local Work 연결 수 또는 중복 식별자를 확인하세요.")
        self.rpc_client = rpc_client if rpc_client is not None else LocalWorkRPCClient()
        self.clock = clock or _lw_time.time
        self._lock = _lw_threading.RLock()
        self._closed = False
        self._round_robin = 0
        self._events = _lw_collections.deque(maxlen=100)
        self._seen = _lw_collections.OrderedDict()
        self._files = _lw_collections.OrderedDict()
        self._state = {b["id"]: {"turns": {}, "selected": None, "lastReceiptAt": None,
            "lastAttemptAt": None, "lastSuccessAt": None, "error": None,
            "lastValidTitle": None, "titleStatus": "unconfirmed", "titleTruncated": False,
            "threadStatus": "unknown", "activeFlags": [], "toolMetadataAvailable": False,
            "toolMetadataTruncated": False, "hookHistoryTruncated": False} for b in self.bindings}
        self._diagnostics = {"rejectedReceipts": 0, "duplicateReceipts": 0, "receiptReadErrors": 0,
                             "unboundReceiptsIgnored": 0, "receiptScanTruncated": False,
                             "receiptScanTruncatedCount": 0}

    @property
    def bound_thread_hashes(self):
        return frozenset(_lw_sha(binding["threadId"]) for binding in self.bindings)

    def _once(self, key):
        if key in self._seen:
            return False
        self._seen[key] = None
        while len(self._seen) > 4096:
            self._seen.popitem(last=False)
        return True

    def _emit(self, binding, turn_hash, kind, label, timestamp, suffix):
        key = (binding["id"], turn_hash, suffix)
        if not self._once(key):
            return
        self._events.append({"id": "work-event-"+_lw_sha(repr(key))[:24],
            "provider": "work", "projectId": "work-project-"+_lw_sha(binding["id"])[:24],
            "agentId": "work-agent-"+_lw_sha(binding["threadId"])[:24], "sessionId": _lw_sha(binding["threadId"]),
            "connectionId": binding["id"], "kind": kind, "label": label, "tool": "",
            "time": _lw_iso(timestamp) if timestamp is not None else None, "turnSHA256": turn_hash})

    def _turn(self, state, turn_hash):
        return state["turns"].setdefault(turn_hash, {"firstAt": None, "lastAt": None,
            "stopSeen": False, "lastHook": None, "outcome": None, "runtimeAt": None,
            "terminalVerified": False, "reportedStatus": "unknown",
            "errors": {}, "toolExitCodes": {}, "postAtByTool": {}, "hasSubmit": False})

    def _receipts(self, binding, state, now):
        folder = _LWPath(binding["receiptDir"])
        if not _lw_plain_directory(folder):
            return
        candidates = []
        scan_truncated = False
        try:
            with _lw_os.scandir(folder) as entries:
                for index, entry in enumerate(entries):
                    if index >= 1024:
                        scan_truncated = True
                        break
                    if entry.name.endswith(".json") and entry.is_file(follow_symlinks=False):
                        stat = entry.stat(follow_symlinks=False)
                        candidates.append((stat.st_mtime_ns, entry.path, stat.st_size))
        except OSError:
            self._diagnostics["receiptReadErrors"] += 1
            return
        if scan_truncated or len(candidates) > 256:
            state["hookHistoryTruncated"] = True
            self._diagnostics["receiptScanTruncated"] = True
            self._diagnostics["receiptScanTruncatedCount"] += 1
        records = []
        for modified, name, size in sorted(candidates, reverse=True)[:256]:
            fingerprint = (binding["id"], name, modified, size)
            if fingerprint in self._files:
                continue
            self._files[fingerprint] = None
            while len(self._files) > 4096:
                self._files.popitem(last=False)
            try:
                path = _LWPath(name)
                if size > 8192 or path.is_symlink() or path.resolve().parent != folder.resolve():
                    raise ValueError()
                raw = path.read_bytes()
                if len(raw) > 8192:
                    raise ValueError()
                data = json.loads(raw)
                if not isinstance(data, dict) or data.get("schemaVersion") != 1 or data.get("diagnosticVersion") != "0.1" or data.get("diagnosticOnly") is not True:
                    raise ValueError()
                if data.get("sessionSHA256") != _lw_sha(binding["sessionId"]):
                    self._diagnostics["unboundReceiptsIgnored"] += 1
                    continue
                event = data.get("hookEvent")
                stamp = _lw_time_value(data.get("observedAtUTC"))
                turn_hash = data.get("turnSHA256")
                tool_hash = data.get("toolUseSHA256")
                if event not in _LW_EVENTS or stamp is None or stamp < 0 or stamp > now+300 or data.get("cwdMatchesIsolatedProbe") is not True:
                    raise ValueError()
                if turn_hash is not None and (not isinstance(turn_hash, str) or not re.fullmatch(r"[0-9a-f]{64}", turn_hash)):
                    raise ValueError()
                if tool_hash is not None and (not isinstance(tool_hash, str) or not re.fullmatch(r"[0-9a-f]{64}", tool_hash)):
                    raise ValueError()
                records.append((stamp, event, turn_hash, tool_hash))
            except (OSError, ValueError, TypeError, RuntimeError, RecursionError):
                self._diagnostics["rejectedReceipts"] += 1
        order = {"SessionStart": 0, "UserPromptSubmit": 1, "PreToolUse": 2, "PostToolUse": 3, "Stop": 4}
        for stamp, event, turn_hash, tool_hash in sorted(records, key=lambda x: (x[0], order.get(x[1], 3))):
            key = (binding["id"], "receipt", event, turn_hash, tool_hash)
            if not self._once(key):
                self._diagnostics["duplicateReceipts"] += 1
                continue
            state["lastReceiptAt"] = max(state["lastReceiptAt"] or stamp, stamp)
            if turn_hash is None:
                continue  # SessionStart/End do not invent a task lifecycle.
            turn = self._turn(state, turn_hash)
            turn["firstAt"] = min(turn["firstAt"] or stamp, stamp)
            turn["lastAt"] = max(turn["lastAt"] or stamp, stamp)
            turn["lastHook"] = event
            turn["stopSeen"] |= event in {"Stop", "Interrupt"}
            turn["hasSubmit"] |= event == "UserPromptSubmit"
            if event == "PostToolUse" and tool_hash is not None:
                turn["postAtByTool"][tool_hash] = stamp
            selected = state["turns"].get(state["selected"], {})
            if state["selected"] is None or turn["firstAt"] >= (selected.get("firstAt") or 0):
                state["selected"] = turn_hash
            kind, label = {"UserPromptSubmit": ("start", "요청 제출"),
                "PreToolUse": ("execute", "도구 작업 시작"), "PostToolUse": ("idle", "도구 응답 확인"),
                "PermissionRequest": ("ask", "승인 요청 기록"), "Stop": ("idle", "종료 확인 중"),
                "Interrupt": ("idle", "중단 확인 중")}.get(event, ("idle", "세션 기록"))
            self._emit(binding, turn_hash, kind, label, stamp, (event, tool_hash))

    def poll(self):
        """One bounded read per binding; no background thread or cached-body I/O."""
        deadline = _lw_time.monotonic() + 4.0
        begin = self._round_robin % max(1, len(self.bindings))
        ordered = self.bindings[begin:] + self.bindings[:begin]
        for binding in ordered:
            if self._closed:
                return
            if _lw_time.monotonic() >= deadline:
                break
            self._round_robin = (self.bindings.index(binding) + 1) % max(1, len(self.bindings))
            now = self.clock()
            with self._lock:
                state = self._state[binding["id"]]
                self._receipts(binding, state, now)
                state["lastAttemptAt"] = now
            try:
                if isinstance(self.rpc_client, LocalWorkRPCClient):
                    result = self.rpc_client.read_binding(binding, timeout=max(.01, deadline-_lw_time.monotonic()))
                else:
                    result = self.rpc_client.read_binding(binding)
                if (not isinstance(result, dict) or result.get("ok") is not True or result.get("threadId") != binding["threadId"]
                        or not isinstance(result.get("cwd"), str) or _lw_norm(result["cwd"]) != _lw_norm(binding["cwd"])):
                    raise LocalWorkRPCError("invalidMetadata")
                with self._lock:
                    state["lastSuccessAt"], state["error"] = self.clock(), None
                    title = _lw_title_metadata(result.get("taskTitle"))
                    if "taskTitle" not in result:
                        title["titleStatus"] = "unconfirmed"
                    elif title["taskTitle"] is None and result.get("titleStatus") == "invalid":
                        title["titleStatus"] = "invalid"
                    state["titleStatus"] = title["titleStatus"]
                    if title["taskTitle"]:
                        state["lastValidTitle"] = title["taskTitle"]
                        state["titleTruncated"] = title["titleTruncated"] or result.get("titleTruncated") is True
                    state["threadStatus"] = result.get("threadStatus", "unknown")
                    if state["threadStatus"] == "systemError":
                        # Metadata transport succeeded; the observed runtime itself
                        # reports an error. Do not relabel the task as failed.
                        state["error"] = "runtimeSystemError"
                    state["activeFlags"] = result.get("activeFlags", [])
                    state["toolMetadataAvailable"] = result.get("toolMetadataAvailable", False)
                    state["toolMetadataTruncated"] = result.get("toolMetadataTruncated", False)
                    runtime_hashes = []
                    for runtime_turn in result.get("turns", [])[:5]:
                        turn_hash = _lw_sha(runtime_turn["id"])
                        runtime_hashes.append(turn_hash)
                        turn = self._turn(state, turn_hash)
                        start = _lw_time_value(runtime_turn.get("startedAt"))
                        if start is not None:
                            turn["firstAt"] = min(turn["firstAt"] or start, start)
                        outcome = runtime_turn.get("status")
                        reported = runtime_turn.get("reportedStatus", outcome)
                        turn["reportedStatus"] = reported if reported in _LW_TERMINAL | {"inProgress"} else "unknown"
                        completed_at = _lw_time_value(runtime_turn.get("completedAt"))
                        verified_terminal = outcome in _LW_TERMINAL and _lw_terminal_time_valid(start, completed_at)
                        if turn["outcome"] in _LW_TERMINAL and not turn.get("terminalVerified", False):
                            turn["outcome"], turn["runtimeAt"] = None, None
                        if verified_terminal and not turn.get("terminalVerified", False):
                            turn["outcome"] = outcome
                            turn["runtimeAt"] = completed_at
                            turn["terminalVerified"] = True
                            kind, label = {"completed": ("complete", "작업 완료"),
                                "failed": ("error", "작업 오류"), "interrupted": ("idle", "작업 중단")}[outcome]
                            self._emit(binding, turn_hash, kind, label, turn["runtimeAt"], ("terminal", outcome))
                        elif outcome == "inProgress" and not turn.get("terminalVerified", False):
                            turn["outcome"], turn["runtimeAt"] = outcome, start
                        elif not turn.get("terminalVerified", False):
                            turn["outcome"], turn["runtimeAt"] = "unknown", None
                    selected = state["turns"].get(state["selected"], {})
                    if runtime_hashes and (state["selected"] is None or state["selected"] in runtime_hashes or now-(selected.get("lastAt") or 0) > 120):
                        state["selected"] = runtime_hashes[0]
                    for tool in result.get("tools", [])[:50]:
                        turn_hash = _lw_sha(tool["turnId"])
                        if turn_hash not in runtime_hashes:
                            continue
                        turn = self._turn(state, turn_hash)
                        code = tool.get("exitCode")
                        if tool.get("status") == "failed" or tool.get("errorPresent") is True or (isinstance(code, int) and not isinstance(code, bool) and code != 0):
                            tool_hash = _lw_sha(tool["id"])
                            turn["errors"][tool_hash] = True
                            if isinstance(code, int) and not isinstance(code, bool):
                                turn["toolExitCodes"][tool_hash] = code
                            occurrence = _lw_time_value(tool.get("completedAt"))
                            if occurrence is None:
                                occurrence = turn["postAtByTool"].get(tool_hash)
                            self._emit(binding, turn_hash, "error", "도구 작업 오류", occurrence, ("tool-error", tool_hash))
                    while len(state["turns"]) > 32:
                        oldest = next((key for key in state["turns"] if key != state["selected"]), None)
                        if oldest is None:
                            break
                        del state["turns"][oldest]
            except Exception as error:
                with self._lock:
                    state["error"] = error.code if isinstance(error, LocalWorkRPCError) else "runtimeUnavailable"
                    state["titleStatus"] = "unavailable"

    def snapshot(self):
        with self._lock:
            now = self.clock()
            projects, agents, sources = [], [], []
            for binding in self.bindings:
                state = self._state[binding["id"]]
                turn_hash = state["selected"]
                turn = state["turns"].get(turn_hash, {})
                runtime_fresh = state["lastSuccessAt"] is not None and now-state["lastSuccessAt"] <= 15 and state["error"] is None
                outcome = turn.get("outcome")
                terminal = outcome in _LW_TERMINAL and turn.get("terminalVerified", False)
                waiting = runtime_fresh and state["threadStatus"] == "active" and bool(state["activeFlags"]) and not terminal
                hook_fresh = turn.get("lastAt") is not None and now-turn["lastAt"] <= 30
                running = runtime_fresh and state["threadStatus"] == "active" and outcome == "inProgress" and not waiting
                authoritative = terminal or running or waiting
                authority = "runtime-turn" if terminal else "runtime-active" if running or waiting else "none"
                if terminal:
                    kind, label = {"completed": ("complete", "작업 완료"), "failed": ("error", "작업 오류"), "interrupted": ("idle", "작업 중단")}[outcome]
                elif waiting:
                    kind, label = "ask", "사용자 확인 대기"
                elif running:
                    kind, label = "execute", "작업 중"
                elif runtime_fresh and hook_fresh and not turn.get("stopSeen"):
                    kind, label = "execute", "작업 진행 기록 · 현재 상태 미확인"
                    authority = "hook-record"
                else:
                    kind, label = "idle", "종료 확인 중" if turn.get("stopSeen") else "상태 확인 불가"
                if not runtime_fresh:
                    authority = "unavailable"
                    if not terminal:
                        kind, label = "idle", "상태 확인 불가"
                project_id = "work-project-"+_lw_sha(binding["id"])[:24]
                title = state["lastValidTitle"]
                title_status = state["titleStatus"]
                if not runtime_fresh and title_status == "valid":
                    title_status = "unavailable" if state["error"] else "stale"
                title_fields = {"name": title or binding["name"], "folderName": binding["name"],
                    "taskTitle": title, "titleSource": "thread-name" if title else "fallback",
                    "titleState": "current" if title and runtime_fresh and title_status == "valid" else "last-known" if title else "missing",
                    "titleStatus": title_status, "titleTruncated": state["titleTruncated"]}
                projects.append({"id": project_id, "connectionId": binding["id"],
                                 "provider": "work", **title_fields})
                updated = turn.get("runtimeAt") if terminal else (turn.get("lastAt") or turn.get("firstAt"))
                if turn_hash is not None:
                    exit_codes = list(turn.get("toolExitCodes", {}).values())
                    agents.append({"id": "work-agent-"+_lw_sha(binding["threadId"])[:24],
                        "projectId": project_id, "sessionId": _lw_sha(binding["sessionId"]),
                        "parentId": None, "provider": "work", "connectionId": binding["id"],
                        **title_fields, "kind": kind, "label": label, "tool": "",
                        "updatedAt": _lw_iso(updated) if updated is not None else None,
                        "turnSHA256": turn_hash, "taskOutcome": outcome if terminal or running else "unknown", "terminal": terminal,
                        "persistedTurnStatus": turn.get("reportedStatus", outcome) or "unknown", "authoritativeState": authoritative,
                        "terminalTimestampVerified": terminal,
                        "stateAuthority": authority, "executionStateKnown": runtime_fresh and authoritative,
                        "waitingAuthoritative": waiting,
                        "stateAvailable": runtime_fresh, "sourceIdentity": "user-confirmed-work-local",
                        "toolErrorCount": len(turn.get("errors", {})), "lastToolExitCode": exit_codes[-1] if exit_codes else None})
                health = "runtime-error" if state["error"] == "runtimeSystemError" else "connected" if runtime_fresh else "disconnected" if state["error"] and state["lastSuccessAt"] is not None else "stale" if state["lastSuccessAt"] is not None else "unknown"
                sources.append({"provider": "work", "connectionId": binding["id"], "available": runtime_fresh,
                    "readError": state["error"] is not None, "status": health,
                    "lastCheckedAt": _lw_iso(state["lastSuccessAt"]) if state["lastSuccessAt"] is not None else None,
                    "lastRuntimeSuccessAt": _lw_iso(state["lastSuccessAt"]) if state["lastSuccessAt"] is not None else None,
                    "lastAttemptAt": _lw_iso(state["lastAttemptAt"]) if state["lastAttemptAt"] is not None else None,
                    "lastReceiptAt": _lw_iso(state["lastReceiptAt"]) if state["lastReceiptAt"] is not None else None,
                    "files": sum(key[0] == binding["id"] for key in self._files),
                    "toolMetadataAvailable": state["toolMetadataAvailable"],
                    "toolMetadataTruncated": state["toolMetadataTruncated"],
                    "hookHistoryTruncated": state["hookHistoryTruncated"],
                    "sourceIdentity": "user-confirmed-work-local", "automaticSourceDiscovery": False})
            return _lw_copy.deepcopy({"projects": projects, "agents": agents, "sources": sources,
                "events": list(reversed(self._events)), "diagnostics": self._diagnostics})

    def close(self):
        self._closed = True
        self.rpc_client.close()


def _failed(value: dict) -> bool:
    status = value.get("status")
    return (value.get("isError") is True or value.get("success") is False
            or (isinstance(status, str) and status in {"failed", "errored", "declined"})
            or bool(value.get("error"))
            or (isinstance(value.get("exit_code"), int)
                and not isinstance(value.get("exit_code"), bool) and value["exit_code"] != 0))


def _child_start(context: dict, state: dict, child: str, ts: str | None, tool: str) -> list[dict]:
    if child == context.get("session_id") or child in state["children"]:
        return []
    state["children"][child] = True
    if len(state["children"]) > _MAX_CALLS:
        del state["children"][next(iter(state["children"]))]
    return _emit(context, "start", ts, tool, label="협업 에이전트 합류", child=child)


def _output(context: dict, state: dict, payload: dict, ts: str | None) -> list[dict]:
    call_id = _identifier(payload.get("call_id")) or _identifier(payload.get("id"))
    call = state["calls"].get(call_id)
    if not call or not _once(state, f"result:{call_id}"):
        return []
    objects = _result_objects(payload.get("output"))
    if any(_failed(obj) for obj in objects):
        return _emit(context, "error", ts, call["tool"], label="도구 작업 오류")
    events = _emit(context, "idle", ts, call["tool"], label="도구 응답 수신")
    if _is_spawn(call["tool"]):
        for obj in objects:
            child = next((_identifier(obj.get(key)) for key in ("agent_id", "thread_id", "new_thread_id")
                          if _identifier(obj.get(key))), None)
            if child:
                events.extend(_child_start(context, state, child, ts, call["tool"]))
                break
    return events


def _item_completed(context: dict, state: dict, payload: dict, ts: str | None) -> list[dict]:
    item = payload.get("item")
    if not isinstance(item, dict) or not isinstance(item.get("type"), str):
        return []
    item_type = re.sub(r"[^a-z]", "", item["type"].lower())
    item_id = _identifier(item.get("id"))
    if item_type in {"agentmessage", "reasoning"} and not _once(state, f"content-item:{item_id}" if item_id else None):
        return []
    phase = "started" if payload.get("type") == "item.started" else "completed"
    if not _once(state, f"item:{phase}:{item_id}" if item_id else None):
        return []
    if item_type == "functioncalloutput":
        return _output(context, state, item, ts)
    if item_type == "subagentactivity":
        child = _identifier(item.get("agent_thread_id"))
        if not child:
            return []
        activity = item.get("kind")
        if activity == "started":
            return _child_start(context, state, child, ts, "spawn_agent")
        if activity == "completed":
            return _emit(context, "complete", ts, label="협업 작업 완료", child=child)
        if activity == "interrupted":
            return _emit(context, "idle", ts, label="협업 작업 중단", child=child)
        return []
    if item_type in {"collabagenttoolcall", "collaborationtoolcall"}:
        tool = _identifier(item.get("tool")) or ""
        if _failed(item):
            return _emit(context, "error", ts, tool, label="협업 요청 오류")
        events = _emit(context, "delegate", ts, tool)
        if _is_spawn(tool) and item.get("status") == "completed":
            children = item.get("receiver_thread_ids", [])
            if isinstance(children, list):
                for value in children[:32]:
                    child = _identifier(value)
                    if child:
                        events.extend(_child_start(context, state, child, ts, tool))
        return events
    kind = {
        "commandexecution": "execute", "filechange": "write", "websearch": "search",
        "imageview": "read", "plan": "plan", "reasoning": "plan",
        "agentmessage": "write", "contextcompaction": "plan",
    }.get(item_type)
    tool = ""
    if item_type in {"mcptoolcall", "dynamictoolcall"}:
        tool = _identifier(item.get("tool")) or ""
        kind = _tool_kind(tool) if tool else "execute"
    if not kind:
        return []
    if _failed(item):
        return _emit(context, "error", ts, tool, label="도구 작업 오류")
    # A matching raw call output already supplied its completion observation.
    if item_id and f"result:{item_id}" in state["seen"]:
        return []
    if item_type == "commandexecution" and phase == "completed":
        # A completed command is a terminal observation, not a fresh start.
        return _emit(context, "idle", ts, tool, label="도구 작업 종료")
    label = "답변 작성" if item_type == "agentmessage" else None
    return _emit(context, kind, ts, tool, label=label)


def _session_meta(context: dict, payload: dict) -> None:
    thread_id = _identifier(payload.get("id"))
    if thread_id:
        context["session_id"] = thread_id
    root = _identifier(payload.get("session_id"))
    if root:
        context["root_session_id"] = root
    parent = _identifier(payload.get("parent_thread_id"))
    source = payload.get("source")
    if isinstance(source, dict) and isinstance(source.get("subagent"), dict):
        context["is_subagent"] = True
        spawn = source["subagent"].get("thread_spawn")
        if isinstance(spawn, dict):
            parent = parent or _identifier(spawn.get("parent_thread_id"))
    if parent:
        context["is_subagent"] = True
        context["parent_session_id"] = parent


def parse_codex(record: dict, context: dict) -> list[dict]:
    """Return safe activity observations; unknown or malformed schemas return [].

    context is per physical file. Callers should reset it when that file is
    replaced/truncated and merge agent identity across parent/child files.
    No record content is retained in context or returned to the browser.
    """
    if not isinstance(record, dict) or not isinstance(context, dict):
        return []
    state = _state(context)
    ts = _timestamp(record.get("timestamp"))
    record_type = record.get("type")
    if not isinstance(record_type, str):
        return []
    payload = record.get("payload")
    if record_type == "session_meta" and isinstance(payload, dict):
        _session_meta(context, payload)
        return []  # Discovery alone does not prove active work.
    ordinal = record.get("ordinal")
    if isinstance(ordinal, int) and not isinstance(ordinal, bool):
        if not _once(state, f"ordinal:{ordinal}"):
            return []
    if record_type == "response_item" and isinstance(payload, dict):
        kind = payload.get("type")
        if not isinstance(kind, str):
            return []
        if kind in {"function_call", "custom_tool_call"}:
            return _call(context, state, payload, ts)
        if kind in {"function_call_output", "custom_tool_call_output"}:
            return _output(context, state, payload, ts)
        if kind in {"web_search_call", "tool_search_call"}:
            return _emit(context, "search", ts, kind)
        if kind == "local_shell_call":
            return _emit(context, "execute", ts, "local_shell_call")
        if kind == "message" and payload.get("role") == "assistant":
            item_id = _identifier(payload.get("id"))
            if not _once(state, f"content-item:{item_id}" if item_id else None):
                return []
            return _emit(context, "write", ts, label="답변 작성")
        if kind == "reasoning":
            item_id = _identifier(payload.get("id"))
            if not _once(state, f"content-item:{item_id}" if item_id else None):
                return []
            return _emit(context, "plan", ts, label="작업 검토")
        return []
    if record_type == "event_msg" and isinstance(payload, dict):
        event_type = payload.get("type")
        if not isinstance(event_type, str):
            return []
        turn_id = _identifier(payload.get("turn_id"))
        if event_type in {"task_started", "turn_started"}:
            if _once(state, f"turn-start:{turn_id}" if turn_id else None):
                return _emit(context, "start", ts)
            return []
        if event_type in {"task_complete", "turn_complete"}:
            if not _once(state, f"turn-end:{turn_id}" if turn_id else None):
                return []
            return _emit(context, "error" if payload.get("error") else "complete", ts)
        if event_type == "turn_aborted":
            return _emit(context, "idle", ts, label="작업 중단")
        if event_type == "error":
            return _emit(context, "error", ts)
        if event_type in {"request_user_input", "exec_approval_request", "apply_patch_approval_request"}:
            return _emit(context, "ask", ts)
        if event_type == "item_completed":
            return _item_completed(context, state, payload, ts)
        return []
    # Official codex exec --json output, when the caller explicitly supplies it.
    # Reading these records does not execute codex or alter an interactive run.
    if record_type == "thread.started":
        thread_id = _identifier(record.get("thread_id"))
        if thread_id:
            context["session_id"] = thread_id
        return []
    if record_type == "turn.started":
        return _emit(context, "start", ts)
    if record_type == "turn.completed":
        return _emit(context, "complete", ts)
    if record_type in {"turn.failed", "error"}:
        return _emit(context, "error", ts)
    if record_type in {"item.started", "item.completed"}:
        return _item_completed(context, state, record, ts)
    return []
