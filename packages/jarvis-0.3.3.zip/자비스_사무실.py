#!/usr/bin/env python3
"""자비스 사무실: 로컬 세션 기록을 읽기 전용으로 관찰하는 서버.

Python 3.10+ 표준 라이브러리만 사용합니다. AI를 실행하거나 설정을 바꾸지
않으며, 외부 네트워크에 요청하지 않습니다. 세션 원문은 HTTP로 보내지 않습니다.
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import heapq
import importlib
import json
import ntpath
import os
from pathlib import Path
import re
import secrets
import stat
import subprocess
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit
import webbrowser

VERSION = "0.3.3"
ROOT = Path(__file__).absolute().parent
MAX_FILES = 96
MAX_INITIAL_BYTES = 256 * 1024
MAX_LINE_BYTES = 1024 * 1024
MAX_TICK_BYTES = 1024 * 1024
MAX_FILE_CHUNK = 64 * 1024
MAX_SCAN_ENTRIES = 20000
MAX_SCAN_DIRS = 4096
MAX_AGENTS = 256
MAX_PROJECTS = 96
MAX_EVENTS = 100
KINDS = {
    "read": "파일 읽기", "write": "파일 수정", "execute": "명령 실행",
    "search": "정보 검색", "plan": "계획 정리", "ask": "사용자 입력 대기",
    "delegate": "동료에게 작업 전달", "start": "작업 시작 기록",
    "complete": "작업 완료 기록", "error": "오류 기록 확인",
    "idle": "도구 작업 종료",
}
PROVIDER_NAMES = {"claude": "Claude", "codex": "Codex"}
# Preserve only labels that the adapters themselves define. A generic kind
# cannot distinguish writing an answer from changing a file, or interruption
# from a successful tool return. Never accept a label copied from a transcript.
ADAPTER_LABELS = {
    "claude": {
        "read": {"파일 읽기", "파일 찾기", "내용 검색", "작업 결과 확인", "작업 지침 읽기"},
        "write": {"파일 작성", "코드 수정", "노트북 수정"},
        "execute": {"명령 실행", "작업 중지 요청"},
        "search": {"웹 검색", "웹페이지 읽기", "연결 도구 찾기", "연결 도구 호출"},
        "plan": {"계획 모드 진입", "작업 계획 갱신", "작업 계획 추가", "작업 계획 확인"},
        "ask": {"계획 확인 요청", "사용자 확인 요청"},
        "delegate": {"작업 위임"},
        "start": {"요청 기록 관찰"},
        "idle": {"도구 작업 종료"},
        "error": {"도구 오류"},
    },
    "codex": {
        "read": {"자료 읽기"}, "write": {"파일 수정", "답변 작성"},
        "execute": {"명령 실행"}, "search": {"정보 검색"},
        "plan": {"작업 계획", "작업 검토"}, "ask": {"사용자 확인 대기"},
        "delegate": {"협업 작업 요청"},
        "start": {"작업 시작", "협업 에이전트 합류"},
        "complete": {"작업 완료", "협업 작업 완료"},
        "error": {"작업 오류", "도구 작업 오류", "협업 요청 오류"},
        "idle": {"다음 작업 대기", "도구 응답 수신", "도구 작업 종료", "협업 작업 중단", "작업 중단"},
    },
}


def iso_time(value=None):
    """Normalize a timestamp, retaining UTC and never inventing an event time."""
    if value is None:
        return None
    try:
        if isinstance(value, (float, int)) and not isinstance(value, bool):
            moment = datetime.fromtimestamp(value, timezone.utc)
        elif isinstance(value, str):
            moment = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if moment.tzinfo is None:
                # Log formats sometimes omit a timezone; do not assume a zone.
                return None
            moment = moment.astimezone(timezone.utc)
        else:
            return None
        return moment.isoformat(timespec="milliseconds").replace("+00:00", "Z")
    except (ValueError, OverflowError, OSError):
        return None


def opaque(namespace, value):
    return namespace + ":" + hashlib.sha256(str(value).encode("utf-8", "replace")).hexdigest()[:20]


def display_basename(value):
    if not isinstance(value, str) or not value:
        return None
    value = ntpath.basename(value.rstrip("/\\"))
    value = "".join(ch for ch in value if ch.isprintable())[:60].strip()
    return value if value not in ("", ".", "..") else None


def safe_tool(value):
    if not isinstance(value, str):
        return ""
    return value if re.fullmatch(r"[A-Za-z][A-Za-z0-9_:.\-/]{0,119}", value) else ""


def safe_label(provider, kind, value):
    allowed = ADAPTER_LABELS.get(provider, {}).get(kind, set())
    return value if isinstance(value, str) and value in allowed else KINDS[kind]


def within_root(path, root):
    """Reject symlinks in the observed root and every relative component."""
    try:
        parts = path.relative_to(root).parts
        if root.is_symlink():
            return False
        current = root
        for component in parts:
            current = current / component
            if current.is_symlink():
                return False
        return path.resolve().is_relative_to(root.resolve())
    except AttributeError:  # Python 3.9 compatibility for alternate runtimes.
        try:
            path.resolve().relative_to(root.resolve())
            return True
        except (ValueError, OSError, RuntimeError):
            return False
    except (ValueError, OSError, RuntimeError):
        return False


class FileCursor:
    def __init__(self, path, root, provider):
        self.path = path
        self.root = root
        self.provider = provider
        self.file_id = opaque("file", str(path))
        self.offset = 0
        self.buffer = b""
        self.buffer_start = 0
        self.discard_line = False
        self.identity = None
        self.last_mtime_ns = None
        self.tail_probe = b""
        self.initialized = False
        self.context = self.new_context()

    def new_context(self):
        relative = self.path.relative_to(self.root)
        is_subagent = "subagents" in relative.parts or self.path.name.startswith("agent-")
        parent = None
        agent_id = None
        if self.provider == "claude" and "subagents" in relative.parts:
            index = relative.parts.index("subagents")
            if index > 0:
                parent = relative.parts[index - 1]
        if is_subagent and self.path.name.startswith("agent-"):
            agent_id = self.path.stem.removeprefix("agent-")
        project_seed = relative.parts[0] if self.provider == "claude" and len(relative.parts) > 1 else "unknown"
        return {
            "file_id": self.file_id,
            "project_id": opaque("project", self.provider + ":" + project_seed),
            "session_id": self.path.stem if self.provider == "claude" and not is_subagent else self.file_id,
            "is_subagent": is_subagent,
            "parent_session_id": parent,
            **({"agent_id": agent_id} if agent_id else {}),
        }

    def reset(self):
        self.offset = 0
        self.buffer = b""
        self.buffer_start = 0
        self.discard_line = False
        self.initialized = False
        self.last_mtime_ns = None
        self.tail_probe = b""
        self.context = self.new_context()


class Monitor:
    """Incremental, bounded reader. Tests can inject parsers and temporary roots."""
    def __init__(self, claude_dir, codex_dir, parsers=None):
        self.roots = {
            "claude": Path(claude_dir).expanduser().absolute(),
            "codex": Path(codex_dir).expanduser().absolute(),
        }
        self.parsers = parsers if parsers is not None else {
            provider: getattr(importlib.import_module(provider + "_adapter"), "parse_" + provider)
            for provider in self.roots
        }
        self.cursors = {}
        self.projects = collections.OrderedDict()
        self.agents = collections.OrderedDict()
        self.events = collections.deque(maxlen=MAX_EVENTS)
        self.seen = collections.OrderedDict()
        self.diagnostics = {"malformedLines": 0, "readErrors": 0}
        self.available = {provider: False for provider in self.roots}
        self.source_errors = {provider: False for provider in self.roots}
        self.last_scan_at = None
        self.last_scan = -float("inf")
        self.last_event_at = None
        self.round_robin = 0
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.thread = None

    def _discover(self, provider, root):
        found = []
        self.source_errors[provider] = False
        try:
            available = root.is_dir() and not root.is_symlink()
        except OSError:
            available = False
        self.available[provider] = available
        if not available:
            return found
        queue = collections.deque([root])
        scanned_dirs = scanned_entries = 0
        while queue and scanned_dirs < MAX_SCAN_DIRS and scanned_entries < MAX_SCAN_ENTRIES:
            directory = queue.popleft()
            scanned_dirs += 1
            try:
                if not within_root(directory, root):
                    continue
                with os.scandir(directory) as entries:
                    for entry in entries:
                        scanned_entries += 1
                        if scanned_entries > MAX_SCAN_ENTRIES:
                            break
                        if entry.is_symlink():
                            continue
                        if entry.is_dir(follow_symlinks=False):
                            queue.append(Path(entry.path))
                        elif entry.name.endswith(".jsonl") and entry.is_file(follow_symlinks=False):
                            info = entry.stat(follow_symlinks=False)
                            found.append((info.st_mtime, provider, Path(entry.path)))
            except OSError:
                self.diagnostics["readErrors"] += 1
                self.source_errors[provider] = True
        return found

    def scan(self):
        with self.lock:
            candidates = []
            for provider, root in self.roots.items():
                candidates.extend(self._discover(provider, root))
            selected = sorted(heapq.nlargest(MAX_FILES, candidates), key=lambda item: item[0])
            retained = {}
            for _, provider, path in selected:
                key = (provider, str(path))
                retained[key] = self.cursors.get(key) or FileCursor(path, self.roots[provider], provider)
            self.cursors = retained
            self.last_scan = time.monotonic()
            self.last_scan_at = iso_time(time.time())

    def _metadata(self, record, cursor):
        provider = cursor.provider
        context = cursor.context
        metadata = record.get("payload") if provider == "codex" and record.get("type") == "session_meta" else record
        if not isinstance(metadata, dict):
            return
        cwd = metadata.get("cwd")
        name = display_basename(cwd)
        if name:
            context["project_id"] = opaque("project", provider + ":" + cwd.replace("\\", "/").rstrip("/"))
            context["project_name"] = name
        if provider == "codex" and record.get("type") == "session_meta":
            if isinstance(metadata.get("id"), str):
                context["session_id"] = metadata["id"]
            source = metadata.get("source")
            if isinstance(source, dict):
                subagent = source.get("subagent")
                spawn = subagent.get("spawn") if isinstance(subagent, dict) else None
                parent = spawn.get("parent_thread_id") if isinstance(spawn, dict) else None
                if isinstance(parent, str):
                    context["is_subagent"] = True
                    context["parent_session_id"] = parent
        elif provider == "claude":
            session = metadata.get("sessionId") or metadata.get("session_id")
            if isinstance(session, str) and session and not context.get("is_subagent"):
                context["session_id"] = session
        project_id = context["project_id"]
        self.projects[project_id] = {
            "id": project_id,
            "name": context.get("project_name") or (PROVIDER_NAMES[provider] + " 프로젝트"),
            "provider": provider,
        }
        self.projects.move_to_end(project_id)
        while len(self.projects) > MAX_PROJECTS:
            self.projects.popitem(last=False)

    def _record(self, raw_line, cursor, position, file_mtime, metadata_only=False):
        try:
            record = json.loads(raw_line.decode("utf-8-sig"))
            if not isinstance(record, dict):
                raise ValueError("record is not an object")
        except (UnicodeDecodeError, ValueError, RecursionError):
            self.diagnostics["malformedLines"] += 1
            return
        self._metadata(record, cursor)
        if metadata_only:
            # Let metadata-aware adapters establish IDs, without replaying history.
            if record.get("type") == "session_meta":
                try:
                    self.parsers[cursor.provider](record, cursor.context)
                except (Exception,):
                    self.diagnostics["readErrors"] += 1
            return
        try:
            observed = self.parsers[cursor.provider](record, cursor.context)
        except Exception:
            # A future log schema must never kill monitoring or expose raw data.
            self.diagnostics["readErrors"] += 1
            return
        if not isinstance(observed, list):
            return
        for index, event in enumerate(observed[:32]):
            if not isinstance(event, dict) or event.get("kind") not in KINDS:
                continue
            provider = cursor.provider
            raw_session = event.get("session_id") or cursor.context["session_id"]
            raw_agent = event.get("agent_id") or raw_session
            raw_parent = event.get("parent_id")
            identity_input = "|".join((provider, str(raw_session), str(raw_agent), str(position), str(index), hashlib.sha256(raw_line).hexdigest()))
            event_id = opaque("event", identity_input)
            if event_id in self.seen:
                continue
            self.seen[event_id] = True
            while len(self.seen) > 4096:
                self.seen.popitem(last=False)
            session_id = opaque(provider + ":session", raw_session)
            agent_id = opaque(provider + ":agent", raw_agent)
            parent_id = opaque(provider + ":agent", raw_parent) if raw_parent else None
            project_id = cursor.context["project_id"]
            # A copied/touched file may have a recent mtime and very old records.
            # Unknown event times must stay unknown instead of looking live.
            timestamp = iso_time(event.get("timestamp")) or iso_time(record.get("timestamp"))
            kind = event["kind"]
            tool = safe_tool(event.get("tool", ""))
            label = safe_label(provider, kind, event.get("label"))
            normalized = {
                "id": event_id, "projectId": project_id, "sessionId": session_id,
                "agentId": agent_id, "provider": provider, "kind": kind,
                "label": label, "tool": tool, "time": timestamp,
            }
            self.events.append(normalized)
            if timestamp and (not self.last_event_at or timestamp > self.last_event_at):
                self.last_event_at = timestamp
            previous = self.agents.get(agent_id)
            if previous and previous.get("updatedAt") and timestamp and timestamp < previous["updatedAt"]:
                continue
            is_subagent = bool(parent_id or (cursor.context.get("is_subagent") and str(raw_agent) == str(cursor.context.get("agent_id", cursor.context.get("session_id")))))
            if is_subagent:
                name = previous["name"] if previous else "동료 " + str(1 + sum(bool(agent["parentId"]) for agent in self.agents.values()))
            else:
                name = "자비스 (" + PROVIDER_NAMES[provider] + ")"
            self.agents[agent_id] = {
                "id": agent_id, "projectId": project_id, "sessionId": session_id,
                "parentId": parent_id, "provider": provider, "name": name,
                "kind": kind, "label": label, "tool": tool,
                "updatedAt": timestamp,
            }
            self.agents.move_to_end(agent_id)
            while len(self.agents) > MAX_AGENTS:
                self.agents.popitem(last=False)

    def _read_cursor(self, cursor, budget):
        if not within_root(cursor.path, cursor.root):
            return 0
        descriptor = None
        try:
            flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
            descriptor = os.open(cursor.path, flags)
            info = os.fstat(descriptor)
            if not stat.S_ISREG(info.st_mode):
                return 0
            if not within_root(cursor.path, cursor.root):
                return 0
            identity = (info.st_dev, info.st_ino)
            if cursor.identity is not None and (cursor.identity != identity or info.st_size < cursor.offset):
                cursor.reset()
            elif cursor.initialized and cursor.last_mtime_ns != info.st_mtime_ns:
                # Detect a truncate/rewrite that happened entirely between polls.
                changed_prefix = False
                if cursor.tail_probe and info.st_size >= cursor.offset:
                    os.lseek(descriptor, cursor.offset - len(cursor.tail_probe), os.SEEK_SET)
                    changed_prefix = os.read(descriptor, len(cursor.tail_probe)) != cursor.tail_probe
                if changed_prefix or info.st_size <= cursor.offset:
                    cursor.reset()
            cursor.identity = identity
            cursor.last_mtime_ns = info.st_mtime_ns
            if not cursor.initialized:
                cursor.initialized = True
                if info.st_size > MAX_INITIAL_BYTES:
                    # Recover the usual first-line metadata without reading a huge log.
                    # A rewrite probe may have left the descriptor near its tail.
                    os.lseek(descriptor, 0, os.SEEK_SET)
                    head = os.read(descriptor, min(MAX_FILE_CHUNK, info.st_size))
                    first, separator, _ = head.partition(b"\n")
                    if separator:
                        self._record(first, cursor, 0, info.st_mtime, metadata_only=True)
                    cursor.offset = max(0, info.st_size - MAX_INITIAL_BYTES)
                    cursor.buffer_start = cursor.offset
                    cursor.discard_line = cursor.offset > 0
            if info.st_size <= cursor.offset:
                return 0
            os.lseek(descriptor, cursor.offset, os.SEEK_SET)
            data = os.read(descriptor, min(budget, MAX_FILE_CHUNK))
            if not data:
                return 0
            if not cursor.buffer:
                cursor.buffer_start = cursor.offset
            cursor.offset += len(data)
            cursor.tail_probe = (cursor.tail_probe + data)[-128:]
            cursor.buffer += data
            while b"\n" in cursor.buffer:
                line, _, remainder = cursor.buffer.partition(b"\n")
                line_position = cursor.buffer_start
                cursor.buffer_start += len(line) + 1
                cursor.buffer = remainder
                if cursor.discard_line:
                    cursor.discard_line = False
                    continue
                if len(line) > MAX_LINE_BYTES:
                    self.diagnostics["malformedLines"] += 1
                    continue
                if line.strip():
                    self._record(line.rstrip(b"\r"), cursor, line_position, info.st_mtime)
            if len(cursor.buffer) > MAX_LINE_BYTES:
                cursor.buffer_start += len(cursor.buffer)
                cursor.buffer = b""
                if not cursor.discard_line:
                    self.diagnostics["malformedLines"] += 1
                cursor.discard_line = True
            return len(data)
        except (OSError, RuntimeError):
            self.diagnostics["readErrors"] += 1
            self.source_errors[cursor.provider] = True
            return 0
        finally:
            if descriptor is not None:
                os.close(descriptor)

    def tick(self, force_scan=False):
        with self.lock:
            if force_scan or time.monotonic() - self.last_scan >= 3.0:
                self.scan()
            cursors = list(self.cursors.values())
            if not cursors:
                return
            begin = self.round_robin % len(cursors)
            cursors = cursors[begin:] + cursors[:begin]
            self.round_robin += 1
            budget = MAX_TICK_BYTES
            for cursor in cursors:
                if budget <= 0:
                    break
                budget -= self._read_cursor(cursor, budget)

    def snapshot(self):
        with self.lock:
            referenced = {agent["projectId"] for agent in self.agents.values()} | {event["projectId"] for event in self.events}
            return {
                "schema": 1, "mode": "live", "serverTime": iso_time(time.time()),
                "lastEventAt": self.last_event_at,
                "sources": [{"provider": provider, "available": self.available[provider],
                             "lastCheckedAt": self.last_scan_at, "readError": self.source_errors[provider],
                             "files": sum(cursor.provider == provider for cursor in self.cursors.values())}
                            for provider in self.roots],
                "projects": [dict(project) for project in self.projects.values() if project["id"] in referenced],
                "agents": [dict(agent) for agent in self.agents.values()],
                "events": sorted((dict(event) for event in reversed(self.events)), key=lambda event: event["time"] or "", reverse=True),
                "diagnostics": dict(self.diagnostics),
            }

    def start(self):
        self.tick(force_scan=True)
        def loop():
            while not self.stop_event.wait(0.5):
                self.tick()
        self.thread = threading.Thread(target=loop, name="office-log-observer", daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=2)


def native_data_root(index_file):
    """Protocol1's validated layout keeps connections outside version slots.

    Standalone HTML/Python servers never guess a user data directory. The old
    bootstrap already installs all eight payload files into this exact layout.
    """
    try:
        index = Path(index_file).absolute()
        slot = index.parent
        app = slot.parent.parent
        data = app.parent
        if (index.name != "index.html" or slot.parent.name != "versions"
                or app.name != "app" or not within_root(index, data)
                or any(p.is_symlink() or (hasattr(p, "is_junction") and p.is_junction())
                       for p in (index, *index.parents))):
            return None
        for path in (slot / "version.json", app / "active.json"):
            if not within_root(path, data) or path.stat().st_size > 4096:
                return None
        version = json.loads((slot / "version.json").read_text(encoding="utf-8"))
        active = json.loads((app / "active.json").read_text(encoding="utf-8"))
        if not isinstance(version, dict) or not isinstance(active, dict):
            return None
        if (version.get("bootstrapProtocol") != 1 or version.get("version") != VERSION
                or slot.name != VERSION or active.get("version") != VERSION):
            return None
        return data
    except (OSError, ValueError, TypeError, RecursionError):
        return None


class WorkService:
    """Explicit Local Work scopes; only read-only runtime RPCs are delegated.

    The registry is private application data, never payload/release material.
    No project hooks, trust settings, task messages or execution are modified.
    """
    def __init__(self, data_root):
        self.data_root = data_root
        self.bindings = []
        self.observer = None
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.thread = None
        self.config_error = False
        self.runtime = None
        if data_root is None:
            return
        from codex_adapter import find_local_work_runtime
        self.runtime = find_local_work_runtime()
        try:
            path = data_root / "work-connections.json"
            if path.exists():
                if not within_root(path, data_root) or path.stat().st_size > 65536:
                    raise ValueError("invalid registry")
                value = json.loads(path.read_text(encoding="utf-8"))
                if value.get("schemaVersion") != 1 or not isinstance(value.get("bindings"), list) or len(value["bindings"]) > 8:
                    raise ValueError("invalid registry")
                self.bindings = [self._binding(item) for item in value["bindings"]]
                if (len({item["id"] for item in self.bindings}) != len(self.bindings)
                        or len({item["threadId"] for item in self.bindings}) != len(self.bindings)):
                    raise ValueError("duplicate registry binding")
        except (OSError, ValueError, TypeError, AttributeError, RecursionError):
            self.bindings = []
            self.config_error = True
        self._replace_observer()
        self.thread = threading.Thread(target=self._loop, name="office-local-work-observer", daemon=True)
        self.thread.start()

    @staticmethod
    def _binding(item):
        if not isinstance(item, dict) or item.get("confirmedLocalWork") is not True:
            raise ValueError("Work·로컬 실행 출처 확인이 필요합니다.")
        raw_cwd, thread_id = item.get("cwd"), item.get("threadId")
        if not isinstance(raw_cwd, str) or len(raw_cwd) > 1024 or not Path(raw_cwd).is_absolute():
            raise ValueError("절대 작업 폴더가 필요합니다.")
        cwd = Path(raw_cwd).absolute()
        # Resolve is used only after rejecting aliases, without reading contents.
        if any(p.is_symlink() or (hasattr(p, "is_junction") and p.is_junction()) for p in (cwd, *cwd.parents)):
            raise ValueError("링크·junction 작업 폴더는 지원하지 않습니다.")
        if not cwd.is_dir():
            raise ValueError("작업 폴더를 찾을 수 없습니다.")
        if not isinstance(thread_id, str) or not re.fullmatch(r"[0-9a-fA-F-]{36}", thread_id):
            raise ValueError("유효한 작업 식별자가 필요합니다.")
        identity = opaque("work-connection", str(cwd).casefold() + "|" + thread_id)
        return {"id": identity, "cwd": str(cwd), "threadId": thread_id,
                "confirmedLocalWork": True, "name": display_basename(str(cwd)) or "Local Work",
                "receiptDir": str(cwd / "observations")}

    def config(self):
        with self.lock:
            # Display metadata is an I/O-free overlay. Keep the private registry
            # (including its stable folder-based name) byte-for-byte unchanged.
            projects = self.observer.snapshot().get("projects", []) if self.observer else []
            titles = {item.get("connectionId"): item for item in projects}
            bindings = []
            for item in self.bindings:
                display = titles.get(item["id"], {})
                fields = {"name": item["name"], "folderName": item["name"],
                          "taskTitle": None, "titleSource": "fallback",
                          "titleState": "missing", "titleStatus": "unconfirmed", "titleTruncated": False}
                fields.update({key: display[key] for key in fields if key in display})
                bindings.append({**item, **fields})
            return {"supported": self.data_root is not None, "runtimeAvailable": bool(self.runtime),
                    "bindings": bindings,
                    "message": ("연결 설정을 읽지 못했습니다. 원본 파일을 보존했습니다." if self.config_error else
                                "지정한 Local Work만 관찰합니다. 출처는 사용자 확인, 상태는 자동 조회입니다." if self.data_root else
                                "Local Work 연결 저장은 Windows 앱에서 지원합니다.")}

    def _client(self):
        from codex_adapter import LocalWorkRPCClient
        if not self.runtime:
            raise ValueError("지원되는 로컬 Codex 런타임을 찾지 못했습니다.")
        return LocalWorkRPCClient(self.runtime)

    def discover(self, cwd):
        if self.data_root is None:
            raise ValueError("Windows 앱에서 연결해 주세요.")
        # Validation is identical to binding; no project contents are enumerated.
        checked = self._binding({"cwd": cwd, "threadId": "00000000-0000-0000-0000-000000000000", "confirmedLocalWork": True})
        client = self._client()
        try:
            found = client.list_exact_cwd(checked["cwd"])
            metadata = {item["threadId"]: item for item in found.get("candidates", [])
                        if isinstance(item, dict) and isinstance(item.get("threadId"), str)}
            candidates = []
            for identity in found.get("threadIds", []):
                candidate = {"threadId": identity, "name": "작업 " + identity[:8],
                             "folderName": checked["name"], "taskTitle": None,
                             "titleSource": "fallback", "titleState": "missing",
                             "titleStatus": "unconfirmed", "titleTruncated": False, "updatedAt": None}
                candidate.update({key: metadata[identity][key] for key in candidate if identity in metadata and key in metadata[identity]})
                candidates.append(candidate)
        finally:
            client.close()
        return {"ok": True, "candidates": candidates, "truncated": found.get("truncated", False),
                "message": "폴더가 일치하는 작업입니다. 툴팁에서 Work·로컬을 확인한 작업만 선택하세요."}

    def _save(self, bindings):
        path = self.data_root / "work-connections.json"
        if self.config_error or not within_root(path, self.data_root):
            raise ValueError("기존 연결 파일을 보존하기 위해 저장을 중지했습니다.")
        temp = self.data_root / ("work-connections." + secrets.token_hex(12) + ".tmp")
        try:
            with temp.open("x", encoding="utf-8") as stream:
                json.dump({"schemaVersion": 1, "bindings": bindings}, stream, ensure_ascii=False)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, path)
        finally:
            temp.unlink(missing_ok=True)

    def bind(self, value):
        if self.data_root is None:
            raise ValueError("Windows 앱에서 연결해 주세요.")
        binding = self._binding(value)
        client = self._client()
        try:
            checked = client.read_binding(binding, include_tool_metadata=False)
            if checked.get("threadId") != binding["threadId"] or os.path.normcase(checked.get("cwd", "")) != os.path.normcase(binding["cwd"]):
                raise ValueError("작업 식별자 또는 폴더가 일치하지 않습니다.")
        finally:
            client.close()
        with self.lock:
            bindings = [item for item in self.bindings if item["id"] != binding["id"]] + [binding]
            if len(bindings) > 8:
                raise ValueError("Local Work 연결은 최대 8개입니다.")
            self._save(bindings)
            self.bindings = bindings
            self._replace_observer()
            return {"ok": True, **self.config(), "message": "지정한 Local Work를 자동 관찰합니다."}

    def remove(self, identity):
        if self.data_root is None:
            raise ValueError("Windows 앱에서 연결해 주세요.")
        with self.lock:
            bindings = [item for item in self.bindings if item["id"] != identity]
            self._save(bindings)
            self.bindings = bindings
            self._replace_observer()
            return {"ok": True, **self.config(), "message": "연결 범위를 해제했습니다. 작업과 원본 기록은 유지됩니다."}

    def _replace_observer(self):
        if self.observer:
            self.observer.close()
        from codex_adapter import LocalWorkObserver
        self.observer = LocalWorkObserver(self.bindings, rpc_client=self._client() if self.runtime and self.bindings else None)

    def _loop(self):
        while not self.stop_event.is_set():
            with self.lock:
                observer = self.observer
            if observer:
                observer.poll()
            self.stop_event.wait(2)

    def snapshot(self):
        # Observer copies its own snapshot; HTTP polling never performs RPC.
        observer = self.observer
        if observer:
            return observer.snapshot()
        return {"projects": [], "agents": [], "events": [], "sources": [
            {"provider": "work", "available": False, "status": "unconfigured", "files": 0,
             "lastCheckedAt": None, "readError": False}], "diagnostics": {}}

    def merge(self, state):
        work = self.snapshot()
        # The same bound runtime thread must not appear twice as Codex and Work.
        sessions = {opaque("codex:session", item["threadId"]) for item in self.bindings}
        state["agents"] = [item for item in state["agents"] if item.get("sessionId") not in sessions]
        state["events"] = [item for item in state["events"] if item.get("sessionId") not in sessions]
        for key in ("projects", "agents", "events", "sources"):
            state[key].extend(work.get(key, []))
        referenced = {item["projectId"] for item in state["agents"]} | {item["projectId"] for item in state["events"]}
        state["projects"] = [item for item in state["projects"] if item["id"] in referenced]
        state["events"] = sorted(state["events"], key=lambda item: item.get("time") or "", reverse=True)[:100]
        state["diagnostics"]["localWork"] = work.get("diagnostics", {})
        return state

    def close(self):
        self.stop_event.set()
        # close interrupts a bounded query; only owned runtime children are touched.
        if self.observer:
            self.observer.close()
        if self.thread:
            self.thread.join(timeout=6)


ACTIVITY_READER_SCRIPT = r"""
# Bounded read-only Activity worker; process metadata and explicit statuses only.
# No input/focus/invoke/scroll/Realize calls, files, network, or installation.
# The caller owns the hard subprocess deadline (8 seconds) and cleanup.
param(
    [ValidateSet('list', 'read')][string]$Mode = 'read',
    [Alias('WindowHandle')][long]$TargetHwnd = 67312,
    [int]$ExpectedPid = 0,
    [string]$ExpectedStartTicks = ''
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$WarningPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$script:Watch = [System.Diagnostics.Stopwatch]::StartNew()
$script:MaxNodes = 256
$script:MaxChildren = 64
$script:MaxRows = 32
$script:SoftMilliseconds = 5500
$script:Stats = [ordered]@{
    visitedNodes = 0; childQueries = 0; anchorQueries = 0
    listItemRowsFound = 0; rowsWithExplicitStatus = 0; offscreenSkipped = 0
    nodeLimitReached = $false; childLimitReached = $false
    depthLimitReached = $false; rowLimitReached = $false
    softDeadlineReached = $false; providerExceptionCount = 0
    candidateLimitReached = $false
}
$script:Exceptions = @{}
$script:Rows = New-Object 'System.Collections.Generic.List[object]'
$script:Candidates = New-Object 'System.Collections.Generic.List[object]'
$script:Result = [ordered]@{
    schemaVersion = 1; mode = $Mode; collectionMethod = 'windows-uia'; readOnly = $true
    health = 'read_error'; panelState = 'unconfirmed'; toggleState = 'unknown'
    provider = 'unknown'; backendStateKnown = $false
    targetVerified = $false; verifiedTarget = $null; modeLabel = $null
    observedAtUTC = [DateTime]::UtcNow.ToString('o')
    identity = [ordered]@{
        exactWindowHandle = $TargetHwnd; windowProcessId = $null
        positiveProcessId = $false; processNameAllowed = $false
        expectedPidMatched = $false; expectedStartTicksMatched = $false
    }
}

function Record-ProviderException([object]$Failure) {
    $script:Stats.providerExceptionCount++
    $code = 'provider-exception'
    $errorObject = $Failure.Exception
    if ($null -ne $errorObject) {
        $typeName = $errorObject.GetType().Name
        if ($typeName -eq 'ElementNotAvailableException') { $code = 'element-unavailable' }
        elseif ($typeName -eq 'UnauthorizedAccessException') { $code = 'access-denied' }
        elseif ($typeName -eq 'COMException') { $code = 'provider-com-error' }
    }
    if (-not $script:Exceptions.ContainsKey($code)) { $script:Exceptions[$code] = 0 }
    $script:Exceptions[$code]++
}

function Budget-Available {
    if ($script:Watch.ElapsedMilliseconds -ge $script:SoftMilliseconds) {
        $script:Stats.softDeadlineReached = $true
        return $false
    }
    if ($script:Stats.visitedNodes -ge $script:MaxNodes) {
        $script:Stats.nodeLimitReached = $true
        return $false
    }
    return $true
}

function Child-Elements([object]$Element) {
    $items = New-Object 'System.Collections.Generic.List[object]'
    if (-not (Budget-Available)) { return [pscustomobject]@{ Items = $items } }
    try {
        $script:Stats.childQueries++
        $found = $Element.FindAll(
            [System.Windows.Automation.TreeScope]::Children,
            [System.Windows.Automation.Condition]::TrueCondition)
        $take = [Math]::Min($found.Count, $script:MaxChildren)
        if ($found.Count -gt $take) { $script:Stats.childLimitReached = $true }
        for ($i = 0; $i -lt $take; $i++) { $items.Add($found[$i]) }
    } catch { Record-ProviderException $_ }
    return [pscustomobject]@{ Items = $items }
}

function Exact-NameCondition([string[]]$Names, [object]$Property) {
    $conditions = New-Object 'System.Collections.Generic.List[System.Windows.Automation.Condition]'
    foreach ($name in $Names) {
        $conditions.Add([System.Windows.Automation.PropertyCondition]::new($Property, $name))
    }
    if ($conditions.Count -eq 1) { return $conditions[0] }
    return [System.Windows.Automation.OrCondition]::new(
        [System.Windows.Automation.Condition[]]$conditions.ToArray())
}

function Find-ChildAnchor([object]$Root, [object]$Condition, [int]$MaxDepth, [bool]$InspectModeSelector = $false) {
    $queue = New-Object 'System.Collections.Generic.Queue[object]'
    $queue.Enqueue([pscustomobject]@{ Element = $Root; Depth = 0 })
    while ($queue.Count -gt 0 -and (Budget-Available)) {
        $entry = $queue.Dequeue()
        $script:Stats.visitedNodes++
        try {
            if ($InspectModeSelector -and $null -eq $script:Result.modeLabel) {
                $selectorMatch = $entry.Element.FindFirst(
                    [System.Windows.Automation.TreeScope]::Children, $script:ModeSelectorCondition)
                if ($null -ne $selectorMatch) { $script:Result.modeLabel = 'Codex' }
            }
            $script:Stats.anchorQueries++
            $match = $entry.Element.FindFirst(
                [System.Windows.Automation.TreeScope]::Children, $Condition)
            if ($null -ne $match) {
                return [pscustomobject]@{ Element = $match; Parent = $entry.Element }
            }
        } catch { Record-ProviderException $_ }
        $children = Child-Elements $entry.Element
        if ($entry.Depth -ge $MaxDepth) {
            if ($children.Items.Count -gt 0) { $script:Stats.depthLimitReached = $true }
            continue
        }
        foreach ($child in $children.Items) {
            $queue.Enqueue([pscustomobject]@{ Element = $child; Depth = $entry.Depth + 1 })
        }
    }
    return $null
}

function Is-Offscreen([object]$Element) {
    try {
        $value = $Element.GetCurrentPropertyValue(
            [System.Windows.Automation.AutomationElement]::IsOffscreenProperty, $true)
        if ($value -is [bool]) { return $value }
    } catch { Record-ProviderException $_ }
    return $true
}

function Read-RowStatus([object]$Row, [int]$Index) {
    $queue = New-Object 'System.Collections.Generic.Queue[object]'
    $statuses = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    $queue.Enqueue([pscustomobject]@{ Element = $Row; Depth = 0 })
    $rowNodes = 0
    while ($queue.Count -gt 0 -and $rowNodes -lt 24 -and (Budget-Available)) {
        $entry = $queue.Dequeue()
        $rowNodes++
        $script:Stats.visitedNodes++
        # Do not inspect the row's Name, title, aggregate Name, or preview.
        if ($entry.Depth -gt 0) {
            try {
                $roleMatch = $entry.Element.FindFirst(
                    [System.Windows.Automation.TreeScope]::Element, $script:StatusRoleCondition)
                if ($null -ne $roleMatch -and -not (Is-Offscreen $entry.Element)) {
                    # Name is read only from an explicitly typed status element.
                    # It is never returned unless it is an exact constant below.
                    $literal = $entry.Element.GetCurrentPropertyValue(
                        [System.Windows.Automation.AutomationElement]::NameProperty, $true)
                    if ($literal -is [string] -and $script:StatusAllowlist.Contains($literal)) {
                        [void]$statuses.Add($literal)
                    }
                    $literal = $null
                }
            } catch { Record-ProviderException $_ }
        }
        if ($entry.Depth -ge 4) { continue }
        $children = Child-Elements $entry.Element
        foreach ($child in $children.Items) {
            $queue.Enqueue([pscustomobject]@{ Element = $child; Depth = $entry.Depth + 1 })
        }
    }
    if ($queue.Count -gt 0) { $script:Stats.depthLimitReached = $true }
    $literalStatus = 'unknown'; $basis = 'no-explicit-status'
    if ($statuses.Count -eq 1) {
        foreach ($explicitStatus in $statuses) { $literalStatus = [string]$explicitStatus; break }
        $basis = 'explicit-status-element'
        $script:Stats.rowsWithExplicitStatus++
    } elseif ($statuses.Count -gt 1) { $basis = 'conflicting-explicit-statuses' }
    return [pscustomobject]@{
        rowIndex = $Index; provider = 'unknown'; sourceEvidence = 'not-exposed'
        uiReportedStatus = $literalStatus; basis = $basis
        backendStateKnown = $false
    }
}

function List-CandidateWindows {
    $script:Result.identity = $null
    foreach ($candidateProcess in @(Get-Process -Name Codex, ChatGPT -ErrorAction SilentlyContinue | Sort-Object Id)) {
        if (-not (Budget-Available)) { break }
        if ($script:Candidates.Count -ge 8) { $script:Stats.candidateLimitReached = $true; break }
        try {
            $candidateHandle = $candidateProcess.MainWindowHandle.ToInt64()
            $candidateName = [string]$candidateProcess.ProcessName
            if ($candidateHandle -le 0 -or $candidateName -notin @('Codex', 'ChatGPT')) { continue }
            $candidateTicks = $candidateProcess.StartTime.Ticks.ToString([Globalization.CultureInfo]::InvariantCulture)
            $script:Candidates.Add([pscustomobject]@{
                handle = $candidateHandle; pid = [int]$candidateProcess.Id
                startTicks = $candidateTicks; processName = $candidateName
            })
        } catch { Record-ProviderException $_ }
        finally { $candidateProcess.Dispose() }
    }
    $script:Result.health = 'observed'
}

function Read-Activity {
    if ($TargetHwnd -le 0 -or $ExpectedPid -le 0 -or $ExpectedStartTicks -notmatch '^[0-9]{1,19}$') {
        $script:Result.health = 'target_lost'
        return
    }
    $null = Add-Type -AssemblyName WindowsBase
    $null = Add-Type -AssemblyName UIAutomationTypes
    $null = Add-Type -AssemblyName UIAutomationClient
    try {
        $window = [System.Windows.Automation.AutomationElement]::FromHandle([IntPtr]$TargetHwnd)
        $targetPidValue = $window.GetCurrentPropertyValue(
            [System.Windows.Automation.AutomationElement]::ProcessIdProperty, $true)
        if ($targetPidValue -isnot [int] -or $targetPidValue -le 0) {
            $script:Result.health = 'target_lost'; return
        }
        $script:Result.identity.windowProcessId = $targetPidValue
        $script:Result.identity.positiveProcessId = $true
        $script:Result.identity.expectedPidMatched = $targetPidValue -eq $ExpectedPid
        if (-not $script:Result.identity.expectedPidMatched) {
            $script:Result.health = 'target_lost'; return
        }
        $targetProcess = [Diagnostics.Process]::GetProcessById($targetPidValue)
        try {
            $targetProcessName = [string]$targetProcess.ProcessName
            $targetStartTicks = $targetProcess.StartTime.Ticks.ToString([Globalization.CultureInfo]::InvariantCulture)
            $script:Result.identity.processNameAllowed = $targetProcessName -in @('Codex', 'ChatGPT')
            $script:Result.identity.expectedStartTicksMatched = [string]::Equals($targetStartTicks, $ExpectedStartTicks, [StringComparison]::Ordinal)
            if ($targetProcess.HasExited -or -not $script:Result.identity.processNameAllowed -or -not $script:Result.identity.expectedStartTicksMatched) {
                $script:Result.health = 'target_lost'; return
            }
            $script:Result.verifiedTarget = [ordered]@{
                handle = $TargetHwnd; pid = $targetPidValue
                startTicks = $targetStartTicks; processName = $targetProcessName
            }
            $script:Result.targetVerified = $true
        } finally { $targetProcess.Dispose() }
    } catch {
        Record-ProviderException $_
        $script:Result.health = 'target_lost'
        return
    }
    $button = [System.Windows.Automation.PropertyCondition]::new(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
        [System.Windows.Automation.ControlType]::Button)
    $checkBox = [System.Windows.Automation.PropertyCondition]::new(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
        [System.Windows.Automation.ControlType]::CheckBox)
    $toggleType = [System.Windows.Automation.OrCondition]::new($button, $checkBox)
    $selectorName = Exact-NameCondition @('모드 전환, 현재 모드: Codex') ([System.Windows.Automation.AutomationElement]::NameProperty)
    $script:ModeSelectorCondition = [System.Windows.Automation.AndCondition]::new($button, $selectorName)
    $closedToggleNames = @('활동 보기 켜기', 'Turn on activity view', '활동 보기', '활동 보기, 확인 필요')
    $toggleNames = Exact-NameCondition (@('활동 보기 끄기', 'Turn off activity view') + $closedToggleNames) ([System.Windows.Automation.AutomationElement]::NameProperty)
    $toggleCondition = [System.Windows.Automation.AndCondition]::new($toggleType, $toggleNames)
    $toggle = Find-ChildAnchor $window $toggleCondition 14 $true
    if ($null -eq $toggle) {
        $script:Result.health = 'read_error'; $script:Result.panelState = 'absent-or-unexposed'
        if ($script:Stats.nodeLimitReached -or $script:Stats.childLimitReached -or $script:Stats.depthLimitReached -or $script:Stats.softDeadlineReached) { $script:Result.panelState = 'unconfirmed' }
        return
    }
    $toggleName = $toggle.Element.GetCurrentPropertyValue([System.Windows.Automation.AutomationElement]::NameProperty, $true)
    $isOff = $toggleName -in $closedToggleNames
    $toggleName = $null
    if ($isOff) {
        $script:Result.health = 'panel_closed'; $script:Result.panelState = 'off'; $script:Result.toggleState = 'off'
        return
    }
    $script:Result.toggleState = 'on'
    if (Is-Offscreen $toggle.Element) {
        $script:Result.health = 'offscreen'; $script:Result.panelState = 'not-visible'
        return
    }
    # Only the toggle's immediate parent may be the Activity context.
    $activityHomeCondition = Exact-NameCondition @('홈', 'Home') ([System.Windows.Automation.AutomationElement]::NameProperty)
    $contextMatch = $toggle.Parent.FindFirst([System.Windows.Automation.TreeScope]::Element, $activityHomeCondition)
    if ($null -eq $contextMatch) { $script:Result.health = 'read_error'; return }
    $optionName = Exact-NameCondition @('활동 보기 옵션', 'Activity view options') ([System.Windows.Automation.AutomationElement]::NameProperty)
    $optionCondition = [System.Windows.Automation.AndCondition]::new($button, $optionName)
    $options = Find-ChildAnchor $toggle.Parent $optionCondition 6
    if ($null -eq $options) { $script:Result.health = 'read_error'; return }
    if (Is-Offscreen $options.Element) {
        $script:Result.health = 'offscreen'; $script:Result.panelState = 'not-visible'
        return
    }
    $script:Result.panelState = 'visible'; $script:Result.health = 'observed'
    $statusType = [System.Windows.Automation.PropertyCondition]::new(
        [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
        [System.Windows.Automation.ControlType]::StatusBar)
    $statusNames = Exact-NameCondition @('상태', '상태 표시줄', 'status', 'status bar') ([System.Windows.Automation.AutomationElement]::LocalizedControlTypeProperty)
    $script:StatusRoleCondition = [System.Windows.Automation.OrCondition]::new($statusType, $statusNames)
    $script:StatusAllowlist = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    foreach ($statusLiteral in @('작업 중', '작업중', 'Running', 'Working', 'In progress', '상태 작업 중', '입력 대기', 'Waiting for input', 'Needs input', '완료', 'Completed', 'Complete', '오류', '실패', 'Error', 'Failed', '일시 정지', 'Paused', '차단됨', 'Blocked', '준비됨', 'Ready')) {
        [void]$script:StatusAllowlist.Add($statusLiteral)
    }
    $queue = New-Object 'System.Collections.Generic.Queue[object]'
    $queue.Enqueue([pscustomobject]@{ Element = $toggle.Parent; Depth = 0 })
    while ($queue.Count -gt 0 -and (Budget-Available)) {
        $entry = $queue.Dequeue(); $script:Stats.visitedNodes++
        try {
            $kind = $entry.Element.GetCurrentPropertyValue([System.Windows.Automation.AutomationElement]::ControlTypeProperty, $true)
            if ($kind -eq [System.Windows.Automation.ControlType]::ListItem) {
                $script:Stats.listItemRowsFound++
                if (Is-Offscreen $entry.Element) { $script:Stats.offscreenSkipped++; continue }
                if ($script:Rows.Count -ge $script:MaxRows) { $script:Stats.rowLimitReached = $true; break }
                $row = Read-RowStatus $entry.Element ($script:Rows.Count + 1)
                $script:Rows.Add($row)
                continue
            }
            if ($entry.Depth -ge 6) { $script:Stats.depthLimitReached = $true; continue }
            $children = Child-Elements $entry.Element
            foreach ($child in $children.Items) { $queue.Enqueue([pscustomobject]@{ Element = $child; Depth = $entry.Depth + 1 }) }
        } catch { Record-ProviderException $_ }
    }
}

try {
    if ($Mode -eq 'list') { List-CandidateWindows } else { Read-Activity }
} catch {
    Record-ProviderException $_
    $script:Result.health = 'read_error'
}

$script:Result.rows = @($script:Rows.ToArray())
$script:Result.candidates = @($script:Candidates.ToArray())
$script:Result.rowCount = $script:Rows.Count
$script:Result.rowsObserved = $script:Rows.Count -gt 0
$script:Result.stats = $script:Stats
$script:Result.elapsedMilliseconds = $script:Watch.ElapsedMilliseconds
$script:Result.truncated = [bool]($script:Stats.nodeLimitReached -or $script:Stats.childLimitReached -or $script:Stats.depthLimitReached -or $script:Stats.rowLimitReached -or $script:Stats.softDeadlineReached -or $script:Stats.candidateLimitReached)
if ($script:Result.health -eq 'observed' -and ($script:Result.truncated -or $script:Stats.providerExceptionCount -gt 0)) { $script:Result.health = 'read_error' }
$script:Result.completeCoverage = $false
$script:Result.currentVisibleScopeComplete = $script:Result.health -eq 'observed' -and -not $script:Result.truncated
$script:Result.coverage = 'current visible exposed Activity rows only; no full-history guarantee'
$script:Result.observedAtUTC = [DateTime]::UtcNow.ToString('o')
$failures = New-Object 'System.Collections.Generic.List[object]'
foreach ($code in @($script:Exceptions.Keys | Sort-Object)) { $failures.Add([pscustomobject]@{ code = $code; count = $script:Exceptions[$code] }) }
$script:Result.providerExceptions = @($failures.ToArray())
$script:Result | ConvertTo-Json -Depth 8 -Compress

"""


class ActivityService:
    """Opt-in UI observations, never runtime agents or task outcomes.

    The worker is a fixed read-only Windows UIA program in an owned child.
    Only a user-selected existing host window is observed. Nothing is clicked,
    focused, scrolled, opened or marked as read by the collector.
    """
    HEALTH = {'observed', 'panel_closed', 'offscreen', 'target_lost', 'read_error',
              'timeout', 'unavailable', 'stale', 'unconfigured'}
    LABELS = {'작업 중', '실행 중', '진행 중', 'Running', 'Needs input', 'Ready',
              'Blocked', 'Waiting', 'Unread', '읽지 않음', '입력 대기', '완료', '오류',
              '작업중', 'Working', 'In progress', '상태 작업 중', 'Waiting for input',
              'Completed', 'Complete', '실패', 'Error', 'Failed', '일시 정지', 'Paused', '차단됨', '준비됨'}

    def __init__(self, data_root, worker=None, autostart=True):
        self.data_root = data_root
        self.supported = bool(data_root is not None and (os.name == 'nt' or worker is not None))
        self.lock = threading.RLock()
        self.worker_lock = threading.Lock()
        self.stop_event = threading.Event()
        self.process = None
        self.thread = None
        self.target = None
        self.generation = 0
        self.config_error = False
        self._state = {'health': 'unconfigured', 'rows': [], 'lastCheckedAt': None,
                       'lastObservedAt': None, 'observedAt': None, 'modeLabel': 'unknown'}
        self.worker = worker or self._windows_worker
        if self.supported:
            path = self.data_root / 'activity-connection.json'
            try:
                if path.exists():
                    if not within_root(path, self.data_root) or path.stat().st_size > 4096:
                        raise ValueError('invalid registry')
                    value = json.loads(path.read_text(encoding='utf-8'))
                    if value.get('schemaVersion') != 1:
                        raise ValueError('invalid registry')
                    if value.get('target') is not None:
                        self.target = self._target(value['target'])
            except (OSError, ValueError, TypeError, AttributeError, RecursionError):
                self.config_error = True
            if autostart:
                self.thread = threading.Thread(target=self._loop, name='office-activity-ui', daemon=True)
                self.thread.start()

    @staticmethod
    def _target(value):
        if not isinstance(value, dict):
            raise ValueError('대상 창 형식을 확인하세요.')
        handle, pid, ticks = value.get('handle'), value.get('pid'), value.get('startTicks')
        if (isinstance(handle, bool) or not isinstance(handle, int) or not 0 < handle < 2**53
                or isinstance(pid, bool) or not isinstance(pid, int) or not 0 < pid < 2**31
                or not isinstance(ticks, str) or not re.fullmatch(r'[0-9]{15,20}', ticks)):
            raise ValueError('대상 창을 다시 찾아 선택하세요.')
        name = value.get('processName')
        if not isinstance(name, str) or name.lower() not in {'codex', 'chatgpt'}:
            raise ValueError('지원되는 데스크톱 창만 선택하세요.')
        return {'handle': handle, 'pid': pid, 'startTicks': ticks, 'processName': name}

    def _windows_worker(self, mode, target=None):
        if not self.supported:
            return {'health': 'unavailable', 'rows': []}
        ps = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32/WindowsPowerShell/v1.0/powershell.exe'
        if not ps.is_file():
            return {'health': 'unavailable', 'rows': []}
        arguments = ' -Mode ' + ('list' if mode == 'list' else 'read')
        if target:
            # Strict numeric validation above; no user text enters the command.
            target = self._target(target)
            arguments += (' -TargetHwnd ' + str(target['handle']) + ' -ExpectedPid ' + str(target['pid'])
                          + ' -ExpectedStartTicks ' + target['startTicks'])
        command = [str(ps), '-NoLogo', '-NoProfile', '-NonInteractive', '-Mta',
                   '-Command', '& {\n' + ACTIVITY_READER_SCRIPT + '\n}' + arguments]
        if not self.worker_lock.acquire(timeout=6):
            return {'health': 'timeout', 'rows': []}
        process = None
        try:
            if self.stop_event.is_set():
                return {'health': 'unavailable', 'rows': []}
            process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            with self.lock:
                self.process = process
                if self.stop_event.is_set() and process.poll() is None:
                    process.kill()
            try:
                output, _errors = process.communicate(timeout=8)
            except subprocess.TimeoutExpired:
                process.kill()
                process.communicate(timeout=2)
                return {'health': 'timeout', 'rows': []}
            if process.returncode or len(output) > 65536:
                return {'health': 'read_error', 'rows': []}
            value = json.loads(output.decode('utf-8-sig'))
            return value if isinstance(value, dict) else {'health': 'read_error', 'rows': []}
        except (OSError, ValueError, UnicodeError, subprocess.SubprocessError):
            return {'health': 'read_error', 'rows': []}
        finally:
            if process and process.poll() is None:
                process.kill()
                process.communicate(timeout=2)
            with self.lock:
                if self.process is process:
                    self.process = None
            self.worker_lock.release()

    def discover(self):
        if not self.supported:
            raise ValueError('Windows 앱에서 지원되는 창을 선택하세요.')
        value = self.worker('list', None)
        candidates = []
        values = value.get('candidates', []) if isinstance(value, dict) else []
        for item in (values if isinstance(values, list) else [])[:8]:
            try:
                candidates.append(self._target(item))
            except ValueError:
                pass
        return {'ok': True, 'candidates': candidates,
                'message': '작업 제목을 가져오지 않고 기존 데스크톱 창만 찾았습니다.' if candidates else
                '지원되는 창을 찾지 못했습니다. 보안 설정을 바꾸지 않고 기존 앱의 창을 열어 주세요.'}

    def _save(self, target):
        if self.config_error:
            raise ValueError('기존 연결 파일을 보존하기 위해 저장을 중지했습니다.')
        path = self.data_root / 'activity-connection.json'
        if not within_root(path, self.data_root):
            raise ValueError('연결 파일 경계를 확인하세요.')
        temporary = self.data_root / ('activity.' + secrets.token_hex(12) + '.tmp')
        try:
            with temporary.open('x', encoding='utf-8') as stream:
                json.dump({'schemaVersion': 1, 'target': target}, stream)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)

    def bind(self, value):
        if not self.supported or not isinstance(value, dict) or value.get('confirmedScreenRead') is not True:
            raise ValueError('선택한 창의 화면 관측을 확인하세요.')
        target = self._target(value)
        result = self.worker('read', target)
        if (not self._verified(result, target)
                or result.get('health') not in {'observed', 'panel_closed', 'offscreen'}):
            raise ValueError('현재 창을 확인하지 못했습니다. 보안 설정을 바꾸지 말고 창을 다시 선택하세요.')
        with self.lock:
            if self.stop_event.is_set():
                raise ValueError('앱이 종료 중입니다.')
            self._save(target)
            self.generation += 1
            self.target = target
            self._state = {'health': 'unconfigured', 'rows': [], 'lastCheckedAt': None,
                           'lastObservedAt': None, 'observedAt': None, 'modeLabel': 'unknown'}
            self._accept(result)
        return {'ok': True, **self.config(), 'message': '선택한 창의 Activity를 읽기만 합니다. 실행 상태와 출처는 화면의 명시 표시 범위입니다.'}

    @staticmethod
    def _verified(result, target):
        return (isinstance(result, dict) and result.get('targetVerified') is True
                and result.get('verifiedTarget') == target)

    def remove(self):
        if not self.supported:
            raise ValueError('Windows 앱에서 연결을 해제하세요.')
        with self.lock:
            self._save(None)
            self.generation += 1
            self.target = None
            self._state = {'health': 'unconfigured', 'rows': [], 'lastCheckedAt': None,
                           'lastObservedAt': None, 'observedAt': None, 'modeLabel': 'unknown'}
        return {'ok': True, **self.config(), 'message': '화면 관측을 해제했습니다. 원본 앱과 작업은 유지됩니다.'}

    def _accept(self, result):
        now = datetime.now(timezone.utc).isoformat()
        if not isinstance(result, dict):
            result = {'health': 'read_error'}
        health = result.get('health')
        if not isinstance(health, str) or health not in self.HEALTH:
            health = 'read_error'
        self._state.update(health=health, lastCheckedAt=now)
        if health != 'observed':
            return
        rows = []
        values = result.get('rows')
        if not isinstance(values, list) or len(values) > 100:
            self._state['health'] = 'read_error'
            return
        for ordinal, row in enumerate(values, 1):
            if not isinstance(row, dict):
                continue
            label = row.get('uiReportedStatus')
            rows.append({'ordinal': ordinal, 'provider': 'unknown',
                         'uiReportedStatus': label if isinstance(label, str) and label in self.LABELS else 'unknown',
                         'eventAt': None, 'authoritativeState': False, 'taskOutcome': 'unknown',
                         'terminal': False, 'waitingAuthoritative': False})
        mode = result.get('modeLabel')
        self._state.update(rows=rows, modeLabel=mode if isinstance(mode, str) and mode in {'Codex', 'ChatGPT', 'Chat', 'Work'} else 'unknown',
                           lastObservedAt=now, observedAt=now)

    def poll_once(self):
        with self.lock:
            target = dict(self.target) if self.target else None
            generation = self.generation
        if not target or self.stop_event.is_set():
            return
        try:
            result = self.worker('read', target)
            if result.get('health') in {'observed', 'panel_closed', 'offscreen'} and not self._verified(result, target):
                result = {'health': 'read_error'}
        except Exception:
            result = {'health': 'read_error'}
        with self.lock:
            if self.target == target and self.generation == generation and not self.stop_event.is_set():
                self._accept(result)

    def _loop(self):
        while not self.stop_event.is_set():
            self.poll_once()
            self.stop_event.wait(3)

    def config(self):
        with self.lock:
            state = dict(self._state)
            state['rows'] = [dict(row) for row in state['rows']]
            checked = state.get('lastCheckedAt')
            if self.target and checked:
                try:
                    elapsed = (datetime.now(timezone.utc) - datetime.fromisoformat(checked)).total_seconds()
                    if elapsed > 15:
                        state['health'] = 'stale'
                except (ValueError, TypeError):
                    state['health'] = 'read_error'
            return {'supported': self.supported, 'enabled': bool(self.target), **state,
                    'scope': 'visible-rows-only', 'collectionMethod': 'activity-ui',
                    'backendStateKnown': False, 'configError': self.config_error,
                    'message': ('기존 연결 파일을 보존했습니다. 연결 파일을 확인하세요.' if self.config_error else
                                '화면 관측은 실제 작업의 실행 결과와 별도입니다. 출처·상태가 없으면 미확인입니다.')}

    def close(self):
        self.stop_event.set()
        with self.lock:
            process = self.process
        if process and process.poll() is None:
            try:
                process.kill()
            except OSError:
                pass
        if self.thread:
            self.thread.join(timeout=4)


class OfficeHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 16

    def __init__(self, monitor, port=8765, index_file=None):
        self.monitor = monitor
        self.index_file = Path(index_file) if index_file else ROOT / "index.html"
        self.work_nonce = secrets.token_urlsafe(32)
        self.work = WorkService(native_data_root(self.index_file))
        self.activity = ActivityService(native_data_root(self.index_file))
        try:
            super().__init__(("127.0.0.1", port), OfficeHandler)
        except Exception:
            self.activity.close()
            self.work.close()
            raise

    def server_close(self):
        self.activity.close()
        self.work.close()
        super().server_close()

    def snapshot(self):
        return self.work.merge(self.monitor.snapshot())


class OfficeHandler(BaseHTTPRequestHandler):
    server_version = "JarvisOffice/" + VERSION
    sys_version = ""

    def setup(self):
        super().setup()
        self.connection.settimeout(5)

    def log_message(self, _format, *args):
        # URLs and request data need not be retained or printed.
        pass

    def _reply(self, code, body, content_type="application/json; charset=utf-8"):
        if not isinstance(body, bytes):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "default-src 'none'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'")
        self.send_header("Connection", "close")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _allowed(self):
        port = self.server.server_port
        hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
        if self.headers.get("Host", "").lower() not in hosts:
            self._reply(403, {"error": "허용되지 않은 호스트입니다."})
            return False
        origin = self.headers.get("Origin")
        if origin is not None and origin.lower() not in {"http://" + host for host in hosts}:
            self._reply(403, {"error": "다른 웹사이트에서 접근할 수 없습니다."})
            return False
        if self.headers.get("Sec-Fetch-Site", "").lower() == "cross-site":
            self._reply(403, {"error": "다른 웹사이트에서 접근할 수 없습니다."})
            return False
        return True

    def do_GET(self):
        if not self._allowed():
            return
        path = urlsplit(self.path).path
        if path in ("/", "/index.html"):
            try:
                body = self.server.index_file.read_bytes()
            except OSError:
                self._reply(503, {"error": "index.html 파일이 필요합니다. 압축을 모두 풀어 주세요."})
                return
            self._reply(200, body, "text/html; charset=utf-8")
        elif path in {"/assets/chiikawa.svg", "/assets/hachiware.svg", "/assets/usagi.svg"}:
            try:
                self._reply(200, (self.server.index_file.parent / path.lstrip("/")).read_bytes(), "image/svg+xml")
            except OSError:
                self._reply(404, {"error": "캐릭터 에셋 없음"})
        elif path == "/api/state":
            self._reply(200, self.server.snapshot())
        elif path == "/api/activity":
            self._reply(200, {**self.server.activity.config(), "nonce": self.server.work_nonce})
        elif path == "/api/work":
            self._reply(200, {**self.server.work.config(), "nonce": self.server.work_nonce})
        elif path == "/api/health":
            self._reply(200, {"ok": True, "version": VERSION, "readOnly": True, "boundTo": "127.0.0.1"})
        else:
            self._reply(404, {"error": "없는 경로입니다."})

    def do_POST(self):
        path = urlsplit(self.path).path
        if path not in {"/api/work/discover", "/api/work/bind", "/api/work/remove",
                        "/api/activity/discover", "/api/activity/bind", "/api/activity/remove"}:
            self._reply(405, {"error": "지원하지 않는 변경 요청입니다."})
            return
        if not self._allowed():
            return
        expected = "http://" + self.headers.get("Host", "").lower()
        if (self.headers.get("Origin", "").lower() != expected
                or not secrets.compare_digest(self.headers.get("X-Jarvis-Nonce", ""), self.server.work_nonce)
                or self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() != "application/json"):
            self._reply(403, {"error": "이 앱에서 연결 범위를 설정해 주세요."})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 4096 or self.headers.get("Transfer-Encoding"):
                raise ValueError("연결 요청 크기가 유효하지 않습니다.")
            value = json.loads(self.rfile.read(length).decode("utf-8"))
            if not isinstance(value, dict):
                raise ValueError("연결 요청 형식이 유효하지 않습니다.")
            if path == "/api/activity/discover":
                result = self.server.activity.discover()
            elif path == "/api/activity/bind":
                result = self.server.activity.bind(value)
            elif path == "/api/activity/remove":
                result = self.server.activity.remove()
            elif path.endswith("/discover"):
                result = self.server.work.discover(value.get("cwd"))
            elif path.endswith("/bind"):
                result = self.server.work.bind(value)
            else:
                result = self.server.work.remove(value.get("id"))
            self._reply(200, result)
        except ValueError as error:
            self._reply(400, {"error": str(error)[:180]})
        except Exception:
            self._reply(503, {"error": "로컬 작업 조회에 실패했습니다. 마지막 확인 시각과 연결을 확인해 주세요."})

    def _unsupported(self):
        self._reply(405, {"error": "지원하지 않는 요청입니다."})

    do_PUT = _unsupported
    do_DELETE = _unsupported
    do_PATCH = _unsupported
    do_OPTIONS = _unsupported
    do_HEAD = _unsupported


def main(argv=None):
    parser = argparse.ArgumentParser(description="자비스 사무실 — 로컬 AI 세션 기록 읽기 전용 관찰")
    parser.add_argument("--port", type=int, default=8765, help="로컬 포트 (기본 8765)")
    parser.add_argument("--no-browser", action="store_true", help="브라우저를 자동으로 열지 않음")
    parser.add_argument("--claude-dir", default=str(Path.home() / ".claude" / "projects"), help="Claude Code 세션 폴더")
    parser.add_argument("--codex-dir", default=str(Path(os.environ.get("CODEX_HOME", str(Path.home() / ".codex"))) / "sessions"), help="Codex 세션 폴더")
    args = parser.parse_args(argv)
    if not 1 <= args.port <= 65535:
        parser.error("포트는 1~65535 범위여야 합니다.")
    try:
        monitor = Monitor(args.claude_dir, args.codex_dir)
        server = OfficeHTTPServer(monitor, port=args.port)
    except ImportError:
        print("오류: 어댑터 파일이 없습니다. ZIP 파일의 내용을 모두 같은 폴더에 풀어 주세요.")
        return 1
    except OSError:
        print("오류: 로컬 포트를 열 수 없습니다. 이미 실행 중이라면 기존 창을 사용하거나 --port 8766으로 실행하세요.")
        return 1
    monitor.start()
    url = f"http://127.0.0.1:{server.server_port}/"
    print("자비스 사무실 " + VERSION)
    print("브라우저 주소: " + url)
    print("로컬 기록 읽기 전용 · 대화 본문/명령/코드 전송 없음")
    print("종료: 이 창에서 Ctrl+C를 누르세요.")
    if not args.no_browser:
        # Launching a local URL does not send session records anywhere.
        try:
            webbrowser.open(url)
        except Exception:
            print("브라우저에서 위 주소를 직접 열어 주세요.")
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print("\n자비스 사무실을 종료합니다.")
    finally:
        monitor.stop()
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
