@echo off
start "" "%~dp0JarvisOffice.exe" --data-dir "%LOCALAPPDATA%\JarvisOffice-Preview-0.3.4"
exit /b
