"""Read-only Claude transcript events, with conversation content kept private.

Only the documented user/assistant ``message.content`` envelope and client
``tool_use`` / ``tool_result`` blocks are interpreted. Other records are ignored.
An observed user request is ``start`` (not proof of a new session); a matched
tool result is ``idle`` or ``error`` (never proof that the session has ended).
Ordinary transcript files do not reliably record session/subagent exit, so this
adapter deliberately does not synthesize ``complete`` events.

Sources checked 2026-10-20:
https://platform.claude.com/cookbook/claude-agent-sdk-05-building-a-session-browser
https://platform.claude.com/docs/en/agents-and-tools/tool-use/handle-tool-calls

The disk format is an implementation detail and may change. Fixtures in the
test suite are synthetic examples based on these documented shapes; no real
user transcript or live Claude process is used by this module or its tests.
"""

from __future__ import annotations

from datetime import datetime
import hashlib
import re
from typing import Any


_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}\Z")
_MCP = re.compile(r"mcp__[A-Za-z0-9_-]+__[A-Za-z0-9_-]+\Z")
_MAX_TRACKED = 1024

# Values are fixed display strings. Tool arguments, paths, names of custom
# MCP servers, prompts, output, and thinking text never enter an event.
_TOOLS: dict[str, tuple[str, str]] = {
    "Read": ("read", "파일 읽기"),
    "Glob": ("read", "파일 찾기"),
    "Grep": ("read", "내용 검색"),
    "Write": ("write", "파일 작성"),
    "Edit": ("write", "코드 수정"),
    "MultiEdit": ("write", "코드 수정"),
    "NotebookEdit": ("write", "노트북 수정"),
    "Bash": ("execute", "명령 실행"),
    "WebSearch": ("search", "웹 검색"),
    "WebFetch": ("search", "웹페이지 읽기"),
    "ToolSearch": ("search", "연결 도구 찾기"),
    "EnterPlanMode": ("plan", "계획 모드 진입"),
    "ExitPlanMode": ("ask", "계획 확인 요청"),
    "TodoWrite": ("plan", "작업 계획 갱신"),
    "TaskCreate": ("plan", "작업 계획 추가"),
    "TaskUpdate": ("plan", "작업 계획 갱신"),
    "TaskList": ("plan", "작업 계획 확인"),
    "TaskGet": ("plan", "작업 계획 확인"),
    "TaskOutput": ("read", "작업 결과 확인"),
    "TaskStop": ("execute", "작업 중지 요청"),
    "AskUserQuestion": ("ask", "사용자 확인 요청"),
    "Agent": ("delegate", "작업 위임"),
    "Task": ("delegate", "작업 위임"),
    "Skill": ("read", "작업 지침 읽기"),
}


def _valid_id(value: Any) -> str | None:
    return value if isinstance(value, str) and _ID.fullmatch(value) else None


def _opaque_file_id(value: Any) -> str:
    """Do not expose a filesystem path if the caller uses one as file_id."""
    valid = _valid_id(value)
    if valid:
        return valid
    raw = value if isinstance(value, str) else "unknown-file"
    return "file-" + hashlib.sha256(raw.encode("utf-8", "replace")).hexdigest()[:20]


def _timestamp(value: Any) -> str | None:
    if not isinstance(value, str) or not (10 < len(value) <= 48) or "T" not in value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    # The source timezone must be explicit; never silently assume UTC.
    return value if parsed.tzinfo is not None else None


def _bounded_remember(items: dict, key: str, value: Any) -> None:
    items[key] = value
    while len(items) > _MAX_TRACKED:
        items.pop(next(iter(items)))


def _identity(record: dict, context: dict) -> tuple[str, str, str | None]:
    file_id = _opaque_file_id(context.get("file_id"))
    record_session = _valid_id(record.get("sessionId")) or _valid_id(record.get("session_id"))
    current_session = _valid_id(context.get("session_id"))
    parent = _valid_id(context.get("parent_session_id"))
    if context.get("is_subagent") is True:
        session_id = parent or record_session or current_session or file_id
        agent_id = (
            _valid_id(record.get("agentId"))
            or _valid_id(record.get("agent_id"))
            or _valid_id(context.get("agent_id"))
        )
        if agent_id:
            context["agent_id"] = agent_id
        else:
            agent_id = file_id if file_id != session_id else "agent-" + file_id
        context["session_id"] = session_id
        return session_id, agent_id, parent
    session_id = record_session or current_session or file_id
    context["session_id"] = session_id
    return session_id, session_id, None


def parse_claude(record: dict, context: dict) -> list[dict]:
    """Normalize one Claude JSONL record without copying its private content.

    ``context`` is owned by the caller and retained per transcript file. It may
    contain file_id, project_id, session_id, is_subagent, parent_session_id, and
    optionally agent_id. Internal state is bounded and contains only IDs and
    fixed public tool names, never raw messages or tool inputs/results.
    """
    if not isinstance(record, dict) or not isinstance(context, dict):
        return []
    role = record.get("type")
    if role not in ("user", "assistant"):
        return []
    message = record.get("message")
    if not isinstance(message, dict) or message.get("role", role) != role:
        return []
    content = message.get("content")
    if not isinstance(content, (list, str)):
        return []

    session_id, agent_id, parent_id = _identity(record, context)
    scope = (session_id, agent_id)
    state = context.get("_claude_state")
    if not isinstance(state, dict) or state.get("scope") != scope:
        state = {"scope": scope, "pending": {}, "seen_tools": {}, "seen_requests": {}}
        context["_claude_state"] = state
    pending = state["pending"]
    seen_tools = state["seen_tools"]
    stamp = _timestamp(record.get("timestamp"))

    def event(kind: str, label: str, tool: str = "") -> dict:
        return {
            "session_id": session_id,
            "agent_id": agent_id,
            "parent_id": parent_id,
            "provider": "claude",
            "kind": kind,
            "label": label,
            "timestamp": stamp,
            "tool": tool,
        }

    events: list[dict] = []
    blocks = content if isinstance(content, list) else []
    if role == "assistant":
        for block in blocks:
            if not isinstance(block, dict) or block.get("type") != "tool_use":
                continue
            tool_id = _valid_id(block.get("id"))
            name = block.get("name")
            if not tool_id or not isinstance(name, str) or tool_id in seen_tools:
                continue
            mapped = _TOOLS.get(name)
            public_tool = name
            if mapped is None and len(name) <= 128 and _MCP.fullmatch(name):
                # A custom MCP name can contain a company/project identifier.
                # Its arguments do not tell us safely whether it reads/writes.
                mapped = ("search", "연결 도구 호출")
                public_tool = ""
            if mapped is None:
                continue
            kind, label = mapped
            _bounded_remember(seen_tools, tool_id, True)
            _bounded_remember(pending, tool_id, (public_tool, kind, label))
            events.append(event(kind, label, public_tool))
        return events

    # User messages also carry tool results. Never label them as new requests.
    has_tool_result = any(
        isinstance(block, dict) and block.get("type") == "tool_result" for block in blocks
    )
    for block in blocks:
        if not isinstance(block, dict) or block.get("type") != "tool_result":
            continue
        tool_id = _valid_id(block.get("tool_use_id"))
        if not tool_id or tool_id not in pending:
            continue
        error = block.get("is_error", False)
        if error is not True and error is not False:
            # Malformed truthy strings or integers are not error evidence.
            continue
        tool, _kind, _label = pending.pop(tool_id)
        if error is True:
            events.append(event("error", "도구 오류", tool))
        elif not pending:
            events.append(event("idle", "도구 작업 종료", tool))

    if has_tool_result or record.get("isMeta") is True or record.get("isCompactSummary") is True:
        return events
    has_text = bool(content.strip()) if isinstance(content, str) else any(
        isinstance(block, dict)
        and block.get("type") == "text"
        and isinstance(block.get("text"), str)
        and bool(block["text"].strip())
        for block in blocks
    )
    if has_text:
        request_id = _valid_id(record.get("uuid"))
        if request_id:
            if request_id in state["seen_requests"]:
                return events
            _bounded_remember(state["seen_requests"], request_id, True)
        events.append(event("start", "요청 기록 관찰"))
    return events
